$(document).ready(function () {
    const url = window.location.href;
    if (url.includes('error')) {
        $('#logoLeft').removeClass('logoLeftOut');
        $('#logoRight').removeClass('logoRightOut');
        $('#logoText').removeClass('logoBottomOut');
        $('#panelContainer').removeClass('panelOut');
        $('#splashContext').removeClass('contextOut');
        $('#logoContainer .place-image').css({display: 'none'});
        $('#logoContainer').append($('#splashLogoContainer'));
		const errorMessage = $("#loginError").text();
        swal({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 5000,
            type: 'error',
			title: errorMessage
		});
    } else {
        if ($(window).width() >= 992) {
            animateLogo();
            setTimeout(function () {
                setSplash();
            }, 2000)
        } else {
            $('#panelContainer').removeClass('panelOut');
        }
    }

    setLanding();


});

$(window).resize(function () {
    setLanding();
});

function setSplash() {
    const splashY = ($('#splashLogoContainer').offset().top) - $(window).scrollTop();
    const logoY = ($('#logoContainer>img').offset().top) - $(window).scrollTop();
    const splashX = ($('#splashLogoContainer').offset().left) - $(window).scrollLeft();
    const logoX = ($('#logoContainer>img').offset().left) - $(window).scrollLeft();

    const offsetY = logoY - splashY;
    const offsetX = logoX - splashX;

    $('#splashLogoContainer').css({
        transition: `0.8s ease-in all`,
        transform: `translate(${offsetX}px,${offsetY}px)`,
        MozTransform: `translate(${offsetX}px,${offsetY}px)`,
        WebkitTransform: `translate(${offsetX}px,${offsetY}px)`,
        msTransform: `translate(${offsetX}px,${offsetY}px)`
    });
    $('#panelContainer').removeClass('panelOut');
    $('#splashContext').removeClass('contextOut');
    setTimeout(function () {


        $('#splashLogoContainer').css({
            transition: '0s linear all',
            transform: 'translate(0,0)',
            MozTransform: 'translate(0,0)',
            WebkitTransform: 'translate(0,-0)',
            msTransform: 'translate(0,0)'
        });
        $('#logoContainer .place-image').css({display: 'none'});
        $('#logoContainer').append($('#splashLogoContainer'));
    }, 1000);

}

function animateLogo() {
    $('#logoMiddle').animate(
        {deg: 360},
        {
            duration: 1000,
            step: function (now) {
                $(this).css({transform: 'rotate(' + now + 'deg)'});
            }
        }
    );

    $('#logoLeft').removeClass('logoLeftOut');
    $('#logoRight').removeClass('logoRightOut');
    $('#logoText').removeClass('logoBottomOut');
}

function setLanding() {
    const landingBox = $('#landingBox');
    const cardContainer = $('#cardContainer');
    if (landingBox) {
        const landingBoxHeight = landingBox.height();
        cardContainer.height(landingBoxHeight - 29);
        setCardItems(landingBoxHeight);
    }
}

function setCardItems(containerHeight) {
    const cardItemHeight = (containerHeight  - 60 - 31) / 6;
    if(cardItemHeight > 40){
        $('.item-card').stop(true,true).height(cardItemHeight);
    }else{
        $('.item-card').stop(true,true).height(40);
    }

}
function checkDevice(){
    if(isMobile()){
        document.getElementById('panel').setAttribute('style', 'display:none !important');
        document.getElementById('app-landing').style.display = "block";
    }else{
        document.getElementById('app-landing').style.display = "none";
        document.getElementById('panel').style.display = "block";
    }
}

function isMobile() {
    return (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) && window.screen.width<768);
}
