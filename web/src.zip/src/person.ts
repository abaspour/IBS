export interface IPerson {
  name: string,
  age: number
}
