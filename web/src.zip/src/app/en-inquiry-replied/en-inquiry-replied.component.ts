import {Component, OnInit} from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import {ToastrService} from "ngx-toastr";
import {InquiryService} from "../shared/services/inquiry.service";
import {TotalResponse} from "../shared/models/TotalResponse";
import {Inquiry} from "../shared/models/inquiry";

@Component({
  selector: 'app-en-inquiry-replied',
  templateUrl: './en-inquiry-replied.component.html',
  styleUrls: ['./en-inquiry-replied.component.scss']
})
export class EnInquiryRepliedComponent implements OnInit {

  inquiries : [Inquiry];
  isWorking= false;
  form: FormGroup = null;
  pageTitle = 'Replied Inquiries List';
  startRow = 1;
  totalRows = 0;
  page =5;
  endRow = 5;
  errorMessage = '';
  inquiryNumber: string;
  inquiryName: string;
  inquiryDate: string;
  replyDate: string;
  filter = false;
  formSubmitAttempt = false;
  criteria = `{ "operator":"and", "criteria" : [  { "fieldName" : "verifyStatus", "operator": "equals", "value" : "r" } ] } `;
  constructor(private router: Router,
              private toastr: ToastrService,
              private inquiryService: InquiryService) {
  }

  ngOnInit() {
    this.form = new FormGroup({
      inquiryNumber: new FormControl(null, Validators.required),
      inquiryName: new FormControl('', Validators.required),
      inquiryDate: new FormControl('', Validators.required),
      endReplyDate: new FormControl('', Validators.required)
    });

    this.subscribe( this.criteria + `&_startRow=${this.startRow-1}&_endRow=${this.endRow}&_sortBy=-replyDate` );
  }
  subscribe(criteria){
    this.inquiryService.getInquiryOther(criteria,this).subscribe({
      next: (data: TotalResponse) => {
        this.inquiries = data.response.data;
        this.endRow=data.response.endRow;
        this.startRow=data.response.startRow+1;
        this.totalRows=data.response.totalRows;
      }
      // error : err => this.errorMessage = err
    });

  }
  onClickPrv(){
    if (this.startRow!=1) {
      this.endRow=this.startRow -1;
      this.startRow=(this.startRow-this.page > 0) ? this.startRow-this.page : 1 ;
      this.subscribe(this.criteria+ `&_startRow=${this.startRow-1}&_endRow=${this.endRow}&_sortBy=-replyDate`);
    }
  }
  onClickNxt(){
    if (this.endRow!=this.totalRows) {
      this.startRow=this.endRow + 1;
      this.endRow=(this.endRow + this.page <= this.totalRows) ? this.endRow + this.page : this.totalRows;
      this.subscribe(this.criteria+ `&_startRow=${this.startRow-1}&_endRow=${this.endRow}&_sortBy=-replyDate`);
    }
  }
  onClickSerchClr(){
    this.inquiryNumber='';
    this.inquiryName='';
    this.inquiryDate='';
    this.replyDate='';
    this.onClickSerch();
  }
  onClickSerch(){
    this.criteria = `{ "operator":"and", "criteria" : [  { "fieldName" : "verifyStatus", "operator": "equals", "value" : "r" } ] } `;
    this.filter = false;
    if (this.inquiryNumber) {
      this.filter = true;
      this.criteria += `,{ "fieldName":"inquiryNumber", "operator":"iContains", "value": "${this.inquiryNumber}"  } `;
    }
    if (this.inquiryName){
      this.filter = true;
      this.criteria += `,{ "fieldName":"inquiryName", "operator":"iContains", "value": "${this.inquiryName}"  } `;
    }
    if (this.inquiryDate){
      this.filter = true;
      this.criteria += `,{ "fieldName":"inquiryDate", "operator":"iContains", "value": "${this.inquiryDate}"  } `;
    }
    if (this.replyDate){
      this.filter = true;
      this.criteria += `,{ "fieldName":"replyDate", "operator":"iContains", "value": "${this.replyDate}"  } `;
    }
    this.criteria += `] } `;
    this.startRow = 1;
    this.endRow = this.page;
    this.subscribe(this.criteria+ `&_startRow=${this.startRow-1}&_endRow=${this.endRow}&_sortBy=-replyDate`);

  }

  onClickB() {
    this.router.navigate(['/']);
  }

  isFieldValid(field: string) {
    return (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSubmitAttempt);
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  download(urll): void {
    this.inquiryService.download(urll).subscribe(blob => {
      const a = document.createElement('a')
      const objectUrl = URL.createObjectURL(blob)
      a.href = objectUrl
      a.download = 'file';
      a.click();
      URL.revokeObjectURL(objectUrl);
    });
  }

}
