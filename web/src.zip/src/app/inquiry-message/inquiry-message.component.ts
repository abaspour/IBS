import {Component, OnInit} from '@angular/core';
import {FormControl, FormGroup} from "@angular/forms";
import {Router} from "@angular/router";
import {ToastrService} from "ngx-toastr";
import {MessageService} from "../shared/services/message.service";
import {TotalResponse} from "../shared/models/TotalResponse";
import {Message} from "../shared/models/message";
import {LocalstorageService} from "../shared/services/localstorage.service";

@Component({
  selector: 'app-inquiry-message',
  templateUrl: './inquiry-message.component.html',
  styleUrls: ['./inquiry-message.component.scss']
})
export class InquiryMessageComponent implements OnInit {

  messages : [Message];
  isWorking= false;
  form: FormGroup = null;
  startRow = 1;
  totalRows = 0;
  page =5;
  endRow = 5;
  errorMessage = '';
  filter = false;
  formSubmitAttempt = false;
  currentUser;

  inquiryNumber: string;
  subject: string;
  messageText: string;
  sendDate: string;
  fileOldName: string;

  criteria = `{  } `;
  baseCriteria = `{  } `;
  constructor(private router: Router,
              private toastr: ToastrService,
              private messageService: MessageService) {
  }

  ngOnInit() {
    if (LocalstorageService.getBasicAuth())
      this.currentUser=JSON.parse(LocalstorageService.getBasicAuth());
    this.criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"userFolderId", "operator":"notEqual" , "value" : "1"  }, { "fieldName":"receiverId", "operator":"equals" , "value" : "${this.currentUser.id}"  } ] } `;

    this.form = new FormGroup({
      inquiryNumber: new FormControl(null),
      messageType: new FormControl(null),
    });
    this.form.get('messageType').valueChanges.subscribe( _ =>{
      if (_==='inbox')
        this.criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"userFolderId", "operator":"notEqual" , "value" : "1"  }, { "fieldName":"receiverId", "operator":"equals" , "value" : "${this.currentUser.id}"  } `;
      else if (_==='outbox')
        this.criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"userFolderId", "operator":"notEqual" , "value" : "1"  }, { "fieldName":"senderId", "operator":"equals" , "value" : "${this.currentUser.id}"  } `;
      else
        this.criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"userFolderId", "operator":"equals" , "value" : "1"  }  `;
      this.baseCriteria=this.criteria;
      this.criteria+=" ] }";
      this.onClickSerchClr(11);
      this.subscribe( this.criteria + `&_startRow=${this.startRow-1}&_endRow=${this.endRow}&_sortBy=-sendDate` );
    });
    this.form.patchValue({messageType: 'inbox'});
  }
  subscribe(criteria){
    this.messageService.getMessage(criteria,this).subscribe({
      next: (data: TotalResponse) => {
        this.messages = data.response.data;
        this.messages.forEach(_ => {
          _.messageText=this.remove( _.messageText);
        })
        this.endRow=data.response.endRow;
        this.startRow=data.response.startRow+1;
        this.totalRows=data.response.totalRows;
      }
      // error : err => this.errorMessage = err
    });

  }
  onClickPrv(){
    if (this.startRow!=1) {
      this.endRow=this.startRow -1;
      this.startRow=(this.startRow-this.page > 0) ? this.startRow-this.page : 1 ;
      this.subscribe(this.criteria+ `&_startRow=${this.startRow-1}&_endRow=${this.endRow}&_sortBy=-sendDate`);
    }
  }
  onClickNxt(){
    if (this.endRow!=this.totalRows) {
      this.startRow=this.endRow + 1;
      this.endRow=(this.endRow + this.page <= this.totalRows) ? this.endRow + this.page : this.totalRows;
      this.subscribe(this.criteria+ `&_startRow=${this.startRow-1}&_endRow=${this.endRow}&_sortBy=-sendDate`);
    }
  }
  onClickSerchClr(patch?){
    this.inquiryNumber='';
    this.subject='';
    this.messageText='';
    this.sendDate='';
    this.fileOldName='';
    if (!patch)
      this.form.patchValue({messageType: 'inbox'});
    this.onClickSerch();
  }
  onClickSerch(){
    this.criteria = this.baseCriteria;
    this.filter = false;
    if (this.inquiryNumber) {
      this.filter = true;
      this.criteria += `,{ "fieldName":"inquiryNumber", "operator":"iContains", "value": "${this.inquiryNumber}"  } `;
    }
    if (this.subject){
      this.filter = true;
      this.criteria += `,{ "fieldName":"subject", "operator":"iContains", "value": "${this.subject}"  } `;
    }
    if (this.sendDate){
      this.filter = true;
      this.criteria += `,{ "fieldName":"sendDate", "operator":"iContains", "value": "${this.sendDate}"  } `;
    }
    if (this.messageText){
      this.filter = true;
      this.criteria += `,{ "fieldName":"messageText", "operator":"iContains", "value": "${this.messageText}"  } `;
    }
    this.criteria += `] } `;
    this.startRow = 1;
    this.endRow = this.page;
    this.subscribe(this.criteria+ `&_startRow=${this.startRow-1}&_endRow=${this.endRow}&_sortBy=-sendDate`);

  }
  onClickR() {
    this.formSubmitAttempt = true;
    if (this.form.get('inquiryNo').value && this.form.get('inquiryCountry').value && this.form.get('contactPersonEmail').value) {
      // this.form.patchValue({countryCallingCode: '93' });
      const criteria= ` ${this.form.get('inquiryNo').value} , ${this.form.get('inquiryCountry').value} , ${this.form.get('contactPersonEmail').value} `;
      // console.log('criteria=', criteria);
      this.messageService.getMessage(criteria,this).subscribe((x: TotalResponse) => {
        if (x.response.totalRows < 0) {
          this.toastr.warning(" error in sending eMail .",'error',{timeOut: 10000});
        } else
        if (x.response.totalRows > 0) {
          this.toastr.info(
            `  inquiryNo:${this.form.get('inquiryNo').value} in Country: already inquiryd in NICICO system. We will contact you by Email.`,
            'info', {timeOut: 10000});
        } else {
          this.toastr.info( " Email sent. please use ID from email in next section and press Continue.");
        }
      });
    }
  }

  onClickB() {
    this.router.navigate(['/']);
  }

  isFieldValid(field: string) {
    return (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSubmitAttempt);
  }

  displayFieldCss(message:Message) {
    return {
      'new': message.isViewed==='n'
    };
  }

  remove(txt){
    let txt1= txt.replace(/<[^>]*>/g, '');
    return txt1.replace(/&nbsp;/g,' ');
  //   return txt.text();
  //   let out="";
  //   let concat=true;
  //   for (let i=0;i<txt.length;i++) {
  //     let rest=txt.substring(i);
  //     if (rest.startsWith("<div") || rest.startsWith("<p ") || rest.startsWith("<br "))
  //       concat=false;
  //     if (concat)
  //       out+=txt.substring(i,i+1);
  //     if (!concat && rest.startsWith(">"))
  //       concat=true;
  //   }
  //   return out;
  }
  transfer(operation,id){
    let data={ isViewed:"na",delete:"na",recover:"na"};
    if (operation==='viewed') {
      data.isViewed='isViewed';
    }
    else if (operation==='delete') {
      data.delete=operation;
    }
    else if (operation==='recover') {
      data.recover=operation;
    }
    const formData = new FormData();
    formData.append('data', JSON.stringify(data));

    this.messageService.updateMessage(formData,id,this).subscribe({
      next: (data: TotalResponse) => {
        this.subscribe(this.criteria+ `&_startRow=${this.startRow-1}&_endRow=${this.endRow}&_sortBy=-sendDate`);
      }
      // error : err => this.errorMessage = err
    });

  }
}
// help operator @@@@@@@ $$$$$$$$$ !!!!!!!!
// [iStartsWith, iNotStartsWith, greaterOrEqualField, iEquals, regexp, iNotContainsField, notContains, containsField, contains, notEqual, lessOrEqualField, iMatchesPattern, iNotEndsWith, iEndsWithPattern, iNotEqual, notStartsWithField, iregexp, greaterOrEqual, lessOrEqual, greaterThan, endsWithField, equals, lessThanField, notBlank, betweenInclusive, iContainsPattern, isBlank, iBetweenInclusive, notEndsWith, iEqualsField, iEndsWithField, and, notEqualField, iStartsWithField, matchesPattern, endsWith, iBetween, or, iEndsWith, iNotContains, notInSet, iStartsWithPattern, containsPattern, iNotStartsWithField, notNull, equalsField, inSet, greaterThanField, startsWithField, between, notEndsWithField, iNotEndsWithField, startsWith, isNull, not, startsWithPattern, lessThan, notStartsWith, iNotEqualField, notContainsField, iContains, iContainsField, endsWithPattern]
