import {AfterViewInit, Component, ElementRef, OnDestroy, OnInit, ViewChildren} from '@angular/core';
import {RegisterPrice} from "../shared/models/register-price";
import {AbstractControl, FormControl, FormControlName, FormGroup, ValidationErrors, Validators} from "@angular/forms";
import {ActivatedRoute, Data, Router} from "@angular/router";
import {ToastrService} from "ngx-toastr";
import {RegisterPriceService} from "../shared/services/register-price.service";
import {TotalResponse} from "../shared/models/TotalResponse";
import {CountryService} from "../shared/services/country.service";
import {Country} from "../country";
import {fromEvent, merge, Observable, Subscription} from "rxjs";
import {debounceTime} from "rxjs/operators";

export const num2prcision = "^\\d*\\.?\\d{0,2}$";
export const num = "^\\d*$";
export const EnglishAlphabetRegex = '^[a-zA-Z]\\S*$';
export const telRegex = '^[+(]{1}\\d{1,4}[\\s)]{0,1}\\d{1,3}\\s{0,1}\\d{3,15}$';


@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.scss']
})
export class ItemComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChildren(FormControlName, {read: ElementRef}) formInputElements: ElementRef[];

  registerPrices: [RegisterPrice];
  countries: [Country];
  fileData: File = null;
  previewUrl: any = null;
  form: FormGroup = null;
  pageTitle = 'استعلامهای جدید یا مشاهده شده';
  startRow = 1;
  totalRows = 0;
  page = 5;
  endRow = 5;
  errorMessage = '';
  id: string;
  inquiryNumber: string;
  inquiryName: string;
  inquiryDate: string;
  endReplyDate: string;
  filter = false;
  formSubmitAttempt = false;

  criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"supplierId", "operator":"notNull"} ] } `;

  constructor(private router: Router,
              private toastr: ToastrService,
              private activeRouter: ActivatedRoute,
              private countryService: CountryService,
              private registerPriceService: RegisterPriceService) {
  }

  ngOnInit() {
    this.form = new FormGroup({
      inquiryNumber: new FormControl(null),
      quantity: new FormControl('', [Validators.required, Validators.min(0), Validators.max(10000001), this.regexValidator(new RegExp(num2prcision), {en: 'en'})]),
      brand: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(200)]),
      model: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(300)]),
      unitWeight: new FormControl(''),
      unitPrice: new FormControl('', [Validators.required, Validators.min(0), Validators.max(10000000001), this.regexValidator(new RegExp(num), {en: 'en'})]),
      modeMaterial: new FormControl(''),
      gheymateGhaleb: new FormControl(''),
      manufacturerCountryId: new FormControl(''),
      modelMaterial: new FormControl(''),
      gheymateModel: new FormControl(''),
      partMaterial: new FormControl(''),
      modateSakhtSample: new FormControl(''),
      hasSample: new FormControl(''),
      modatSakhtAnboh: new FormControl(''),
      guranteeTime: new FormControl(''),
      deliveryDate: new FormControl('', [Validators.required, Validators.min(0), Validators.max(400), this.regexValidator(new RegExp(num), {en: 'en'})]),
      packageCondition: new FormControl(''),
      priceBeforeDiscount: new FormControl(''),
      discount: new FormControl('', [Validators.required, Validators.min(0), Validators.max(100000001), this.regexValidator(new RegExp(num), {en: 'en'})]),
      gheymateKol: new FormControl(''),
      verifyPrice: new FormControl(''),
      supplierDesc: new FormControl(''),
      receiveSample: new FormControl(''),
      existForTest: new FormControl(''),
      receiveAttach: new FormControl('', Validators.required)
    });
    this.form.get('priceBeforeDiscount').disable()
    this.form.get('gheymateKol').disable()
    this.sub = this.activeRouter.params.subscribe((data: Data) => {
      this.id = data.id;
      if (this.id) {
        this.criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"id", "operator":"equals", "value": "${this.id}"  } ] } `;
        this.subscribe(this.criteria + `&_startRow=${this.startRow - 1}&_endRow=${this.endRow}&_sortBy=itemRow`);
        this.countryService.getCountry(this).subscribe(
          (data: TotalResponse) => this.countries = data.response.data
        );
      }
    });
  }

  private sub: Subscription;

  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }

  ngAfterViewInit(): void {
    // Watch for the blur event from any input element on the form.
    // This is required because the valueChanges does not provide notification on blur
    const controlBlurs: Observable<any>[] = this.formInputElements
      .map((formControl: ElementRef) => fromEvent(formControl.nativeElement, 'blur'));

    // Merge the blur event observable with the valueChanges observable
    // so we only need to subscribe once.
    merge(this.form.valueChanges, ...controlBlurs).pipe(
      debounceTime(800)
    ).subscribe(value => {
      this.calculatePricesItem();
    });
  }

  subscribe(criteria) {
    this.form.get('verifyPrice').valueChanges.subscribe(_ => {
      if (_ == 'nv') {
        this.form.get("supplierDesc").setValidators([Validators.required]);
      } else {
        this.form.get("supplierDesc").clearValidators();
      }
      this.form.get("supplierDesc").updateValueAndValidity();
    });
    this.registerPriceService.getRegisterPrice(criteria,this).subscribe({
      next: (data: TotalResponse) => {
        this.registerPrices = data.response.data;
        this.registerPrices.forEach(_ => {
          this.form.patchValue(
            {
              inquiryNumber: _.inquiryNumber,
              quantity: _.quantity,
              brand: _.brand,
              model: _.model,
              unitWeight: _.unitWeight,
              unitPrice: _.unitPrice
              ,
              modeMaterial: _.modeMaterial,
              gheymateGhaleb: _.gheymateGhaleb,
              manufacturerCountryId: _.manufacturerCountryId
              ,
              modelMaterial: _.modelMaterial,
              gheymateModel: _.gheymateModel,
              partMaterial: _.partMaterial,
              modateSakhtSample: _.modateSakhtSample
              ,
              hasSample: _.hasSample,
              guranteeTime: _.guranteeTime,
              deliveryDate: _.deliveryDate,
              packageCondition: _.packageCondition
              ,
              priceBeforeDiscount: _.priceBeforeDiscount,
              discount: _.discount,
              gheymateKol: _.gheymateKol,
              verifyPrice: _.verifyPrice,
              supplierDesc: _.supplierDesc
              ,
              receiveSample: _.receiveSample,
              existForTest: _.existForTest,
              receiveAttach: _.receiveAttach,
              modatSakhtAnboh: _.modatSakhtAnboh
            });
          if (_.modeMaterialRequire && _.modeMaterialRequire == 'y') {
            this.form.get("modeMaterial").setValidators([Validators.required, Validators.maxLength(300), Validators.minLength(3)]);
            this.form.get("modeMaterial").updateValueAndValidity();
          }
          if (_.costMode && _.costMode == 'b') {
            this.form.get("gheymateGhaleb").setValidators([Validators.required, Validators.min(0), Validators.max(1000000001), this.regexValidator(new RegExp(num), {en: 'en'})]);
            this.form.get("gheymateGhaleb").updateValueAndValidity();
          }
          if (_.modelMaterialRequire && _.modelMaterialRequire == 'y') {
            this.form.get("modelMaterial").setValidators([Validators.required, Validators.maxLength(300), Validators.minLength(3)]);
            this.form.get("modelMaterial").updateValueAndValidity();
          }
          if (_.costModel && _.costModel == 'b') {
            this.form.get("gheymateModel").setValidators([Validators.required, Validators.min(0), Validators.max(1000000001), this.regexValidator(new RegExp(num), {en: 'en'})]);
            this.form.get("gheymateModel").updateValueAndValidity();
          }
          if (_.inquiryType && _.inquiryType == 's') {
            this.form.get("unitWeight").setValidators([Validators.required, Validators.min(0), Validators.max(40000), this.regexValidator(new RegExp(num), {en: 'en'})]);
            this.form.get("unitWeight").updateValueAndValidity();
            this.form.get("modatSakhtAnboh").setValidators([Validators.required, Validators.min(0), Validators.max(400), this.regexValidator(new RegExp(num), {en: 'en'})]);
            this.form.get("modatSakhtAnboh").updateValueAndValidity();
            this.form.get("modateSakhtSample").setValidators([Validators.required, Validators.min(0), Validators.max(400), this.regexValidator(new RegExp(num), {en: 'en'})]);
            this.form.get("modateSakhtSample").updateValueAndValidity();
            this.form.get("hasSample").setValidators([Validators.required]);
            this.form.get("hasSample").updateValueAndValidity();
          }
          if (_.partMaterialRequired && _.partMaterialRequired == 'y') {
            this.form.get("partMaterial").setValidators([Validators.required]);
            this.form.get("partMaterial").updateValueAndValidity();
          }
          if (_.packagingConditionRequire && _.packagingConditionRequire == 'y') {
            this.form.get("packageCondition").setValidators([Validators.required]);
            this.form.get("packageCondition").updateValueAndValidity();
          }
          if (_.guranteeTimeRequire && _.guranteeTimeRequire == 'y') {
            this.form.get("guranteeTime").setValidators([Validators.required]);
            this.form.get("guranteeTime").updateValueAndValidity();
          }

        });
        this.endRow = data.response.endRow;
        this.startRow = data.response.startRow + 1;
        this.totalRows = data.response.totalRows;
      }
      // error : err => this.errorMessage = err
    });

  }

  onClickBack(inq) {
    this.router.navigate([`item-list/${inq}`]);
  }

  isFieldValid(field: string) {
    if (this.form.get(field).valid) {
      return null;
    }
    return (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSubmitAttempt);
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  fileProgress(fileInput: any) {
    this.fileData = <File>fileInput.target.files[0];
    this.preview();
  }

  preview() {
    // Show preview
    const mimeType = this.fileData.type;
    if (mimeType.match(/image\/*/) == null) {
      return;
    }

    let reader = new FileReader();
    reader.readAsDataURL(this.fileData);
    reader.onload = (_event) => {
      this.previewUrl = reader.result;
    };
  }

  onClickNxt() {
    this.calculatePricesItem();
    if (!this.form.get('receiveAttach').value) {
      this.toastr.error('لطفا "کلیه ضمائم و اطلاعات فنی ارائه شده توسط خریدار مشاهده گردید." را اقدام نموده و تیک بزنید.',
        'error', {timeOut: 5000});
      this.formSubmitAttempt = false;
      return;
    }
    this.formSubmitAttempt = true;
    if (this.form.valid && this.form.dirty) {
      let _ = this.form.getRawValue();
//
      this.registerPrices[0].inquiryNumber = _.inquiryNumber;
      this.registerPrices[0].quantity = _.quantity;
      this.registerPrices[0].brand = _.brand;
      this.registerPrices[0].model = _.model;
      this.registerPrices[0].unitWeight = _.unitWeight;
      this.registerPrices[0].unitPrice = _.unitPrice;
      this.registerPrices[0].modeMaterial = _.modeMaterial;
      this.registerPrices[0].gheymateGhaleb = _.gheymateGhaleb;
      this.registerPrices[0].manufacturerCountryId = _.manufacturerCountryId;
      this.registerPrices[0].modelMaterial = _.modelMaterial;
      this.registerPrices[0].gheymateModel = _.gheymateModel;
      this.registerPrices[0].partMaterial = _.partMaterial;
      this.registerPrices[0].modateSakhtSample = _.modateSakhtSample;
      this.registerPrices[0].guranteeTime = _.guranteeTime;
      this.registerPrices[0].deliveryDate = _.deliveryDate;
      this.registerPrices[0].packageCondition = _.packageCondition;
      this.registerPrices[0].priceBeforeDiscount = _.priceBeforeDiscount;
      this.registerPrices[0].discount = _.discount;
      this.registerPrices[0].gheymateKol = _.gheymateKol;
      this.registerPrices[0].verifyPrice = _.verifyPrice;
      this.registerPrices[0].supplierDesc = _.supplierDesc;
      this.registerPrices[0].receiveSample = _.receiveSample;
      this.registerPrices[0].existForTest = _.existForTest;
      this.registerPrices[0].receiveAttach = _.receiveAttach;
      this.registerPrices[0].modatSakhtAnboh = _.modatSakhtAnboh;
      this.registerPrices[0].hasSample = _.hasSample;
//
      const formData = new FormData();
      formData.append('data', JSON.stringify(this.registerPrices[0]));
      formData.append('file', this.fileData);

      this.registerPriceService.updateRegisterPrice(formData, this.registerPrices[0].id,this).subscribe(data => {
          this.toastr.success(' با موفقیت ذخیره شد.', 'success', {timeOut: 10000});
          setTimeout(() => {
            this.form.reset();
            this.onClickBack(this.registerPrices[0].inquiryNumber);
          }, 20);
          this.formSubmitAttempt = false;
        },
        error => {
          this.toastr.error(' Error .' + JSON.stringify(error.error), 'Error', {timeOut: 10000});
          setTimeout(() => {
            // this.router.navigate(['/']);
          }, 20000);
        }
      );
    } else if (this.form.valid) {
      this.onClickBack(this.registerPrices[0].inquiryNumber);
    } else {
      this.toastr.error('لطفا نسبت به تکمیل و اصلاح خطا یا خطاها اقدام نمایید.', 'error', {timeOut: 10000});
     }

  }

  regexValidator(regex: RegExp, error: ValidationErrors) {
    return (control: AbstractControl): { [key: string]: any } => {
      if (!control.value) {
        return null;
      }
      const valid = regex.test(control.value);
      console.log(valid)
      return valid ? null : error;
    };
  }

  calculatePricesItem() {
    let unitPrice = 0;
    let qty = 0;
    let modelPrice = 0;
    let ghalebPrice = 0;
    let discountPrice = 0;
    let otherPrice = 0;
    let totlaPrice = 0;
    let pc = 0;
    let spc = 0;
    let priceBeforeDiscount = 0;

    if (this.form.get('unitPrice').valid && this.form.get('unitPrice').value)
      unitPrice = this.form.get('unitPrice').value;
    if (this.form.get('gheymateModel').valid && this.form.get('gheymateModel').value)
      modelPrice = this.form.get('gheymateModel').value;
    if (this.form.get('gheymateGhaleb').valid != null && this.form.get('gheymateGhaleb').value)
      ghalebPrice = this.form.get('gheymateGhaleb').value;
    if (this.form.get('discount').valid != null && this.form.get('discount').value)
      discountPrice = this.form.get('discount').value;
    if (this.form.get('quantity').valid != null && this.form.get('quantity').value)
      qty = this.form.get('quantity').value;
    priceBeforeDiscount = (unitPrice * qty) + (modelPrice * 1) + (ghalebPrice * 1) + (otherPrice * 1) + (pc * 1) + (spc * 1);
    totlaPrice = priceBeforeDiscount - (discountPrice * 1);
    pc = parseFloat(totlaPrice.toFixed(0));
    if (this.form.get('priceBeforeDiscount').value != priceBeforeDiscount || this.form.get('gheymateKol').value != pc) {
      this.form.patchValue({'priceBeforeDiscount': priceBeforeDiscount, 'gheymateKol': pc});

    }

  };

  download(urll): void {
    this.registerPriceService.download(urll).subscribe(blob => {
      const a = document.createElement('a')
      const objectUrl = URL.createObjectURL(blob)
      a.href = objectUrl
      a.download = 'file';
      a.click();
      URL.revokeObjectURL(objectUrl);
    });
  }


}
