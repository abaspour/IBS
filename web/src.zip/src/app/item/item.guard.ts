import {Injectable} from '@angular/core';
import {CanDeactivate} from '@angular/router';
import {Observable} from 'rxjs';
import {ItemComponent} from "./item.component";


@Injectable({
  providedIn: 'root'
})
export class ItemGuard implements CanDeactivate<ItemComponent> {
  canDeactivate(component: ItemComponent): Observable<boolean> | Promise<boolean> | boolean {
    if (component.form.dirty) {
      const countryName = component.form.get('inquiryNumber').value || ' می گردد. مطمئن هستید؟ ';
      return confirm(`خروج از صفحه باعث عدم ذخیره تغییرات داده شده برای استعلام ${countryName}?`);
    }
    return true;
  }
}

