import {Injectable} from '@angular/core';
import {CanDeactivate} from '@angular/router';
import {Observable} from 'rxjs';
import {MessageComponent} from "./message.component";

@Injectable({
  providedIn: 'root'
})
export class MessageGuard implements CanDeactivate<MessageComponent> {
  canDeactivate(component: MessageComponent): Observable<boolean> | Promise<boolean> | boolean {
    if (component.form.dirty) {
      const countryName = component.form.get('inquiryNumber').value || ' می گردد. مطمئن هستید؟ ';
      return confirm(`خروج از صفحه باعث عدم ذخیره تغییرات داده شده برای استعلام ${countryName}?`);
    }
    return true;
  }
}

