import {Component, OnInit} from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {ActivatedRoute, Data, Router} from "@angular/router";
import {ToastrService} from "ngx-toastr";
import {TotalResponse} from "../shared/models/TotalResponse";
import {Subscription} from "rxjs";
import {Inquiry} from "../shared/models/inquiry";
import {InquiryService} from "../shared/services/inquiry.service";
import {Message} from "../shared/models/Message";
import {MessageService} from "../shared/services/message.service";

export const num2prcision = "^\\d*\\.?\\d{0,2}$";
export const num = "^\\d*$";
export const EnglishAlphabetRegex = '^[a-zA-Z]\\S*$';
export const telRegex = '^[+(]{1}\\d{1,4}[\\s)]{0,1}\\d{1,3}\\s{0,1}\\d{3,15}$';


@Component({
  selector: 'app-message',
  templateUrl: './message.component.html',
  styleUrls: ['./message.component.scss']
})
export class MessageComponent implements OnInit {

  inquiries: [Inquiry];
  fileData: File = null;
  previewUrl: any = null;
  form: FormGroup = null;
  startRow = 1;
  totalRows = 0;
  page = 5;
  endRow = 5;
  errorMessage = '';
  inquiryNumber: string;
  inquiryName: string;
  inquiryDate: string;
  endReplyDate: string;
  filter = false;
  formSubmitAttempt = false;
  isWorking;
  reasons=["درخواست تمدید استعلام","درخواست اطلاعات بازرگانی", "درخواست اطلاعات فنی", "طرح مشکل سیستمی (نرم افزاری)",  ];
  reasonE=["Extension","Commercial","Technical","Software"];
  criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"supplierId", "operator":"notNull" } ] } `;

  constructor(private router: Router,
              private toastr: ToastrService,
              private activeRouter: ActivatedRoute,
              private messageService: MessageService,
              private inquiryService: InquiryService) {
  }

  ngOnInit() {
    this.form = new FormGroup({
      inquiryNumber: new FormControl(null),
      messageKind: new FormControl('',Validators.required),
      messageText: new FormControl('',Validators.required),
      file__: new FormControl('')
    });
    this.sub=this.activeRouter.params.subscribe((data: Data) => {
      this.inquiryNumber = data.inquiryNumber;
      if (this.inquiryNumber) {
        this.criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"inquiryNumber", "operator":"equals", "value": "${this.inquiryNumber}"  } ] } `;
        this.subscribe(this.criteria + `&_startRow=${this.startRow - 1}&_endRow=${this.endRow}&_sortBy=inquiryNumber`);
      }
    });
  }
  private sub: Subscription;
  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }

  subscribe(criteria) {
    this.inquiryService.getInquiry(criteria,this ).subscribe({
      next: (data: TotalResponse) => {
        this.inquiries = data.response.data;
        this.inquiries.forEach(_ => {
          this.form.patchValue(
            {
              inquiryNumber: _.inquiryNumber,
            });
        });
        this.endRow = data.response.endRow;
        this.startRow = data.response.startRow + 1;
        this.totalRows = data.response.totalRows;
      }
      // error : err => this.errorMessage = err
    });

  }

  onClickBack(inq) {
    this.router.navigate([`inquiry`]);
  }

  isFieldValid(field: string) {
    if (this.form.get(field).valid) {
      return null;
    }
    return (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSubmitAttempt);
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  fileProgress(fileInput: any) {
    this.fileData = <File>fileInput.target.files[0];
    this.preview();
  }

  preview() {
    // Show preview
    const mimeType = this.fileData.type;
    if (mimeType.match(/image\/*/) == null) {
      return;
    }

    let reader = new FileReader();
    reader.readAsDataURL(this.fileData);
    reader.onload = (_event) => {
      this.previewUrl = reader.result;
    };
  }

  onClickNxt() {
    let _: Message;
    this.formSubmitAttempt = true;
    if (this.form.valid && this.form.dirty) {
      _ = this.form.getRawValue();
//
      let message= {
        inquiryNumber: _.inquiryNumber,
        messageKind: _.messageKind,
        messageText: _.messageText,
        subject: "a"
      };
      message.inquiryNumber=_.inquiryNumber;
      message.messageKind=_.messageKind;
      message.messageText= _.messageText;
      for(let i=0;i<this.reasonE.length;i++)
        if (_.messageKind===this.reasonE[i])
          message.subject=this.reasons[i] + ' جهت '+this.inquiryNumber;
//
      const formData = new FormData();
      formData.append('data', JSON.stringify(message));
      if (this.fileData)
        formData.append('file', this.fileData);

      this.messageService.createMessage(formData,this).subscribe(data => {
          this.toastr.success(' پیام با موفقیت ارسال شد.', 'success', {timeOut: 10000});
          setTimeout(() => {
            this.form.reset();
            this.router.navigate([`inquiry`]);
          }, 200);
          this.formSubmitAttempt = false;
        }
      );
    } else if (this.form.valid) {
      this.router.navigate([`inquiry`]);
    }
    else {
      this.toastr.error('لطفا نسبت به تکمیل و اصلاح خطا یا خطاها اقدام نمایید.', 'error', {timeOut: 10000});
    }

  }

}
