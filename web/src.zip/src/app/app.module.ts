import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {Notfound404Component} from './notfound404/notfound404.component';
import {CanDeactivateGuard} from './can-deactivate-guard.service';
import {FieldErrorDisplayComponent} from './field-error-display/field-error-display.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatListModule} from '@angular/material';
import {MainPageComponent} from './main-page/main-page.component';
import {RegisterService} from './shared/services/register.service';
import {HttpClientModule} from '@angular/common/http';
import {ToastrModule} from 'ngx-toastr';
import {AuditFormComponent} from './audit-form/audit-form.component';
import {HelpAuditComponent} from './help-audit/help-audit.component';
import {WelcomeComponent} from './welcome/welcome.component';
import {InquiryHeaderComponent} from './inquiry-header/inquiry-header.component';
import {InquiryNewComponent} from './inquiry-new/inquiry-new.component';
import {InquiryCommonComponent} from './inquiry-common/inquiry-common.component';
import {ItemListComponent} from './item-list/item-list.component';
import {ItemComponent} from './item/item.component';
import {OtherComponent} from './other/other.component';
import {SendComponent} from './send/send.component';
import {LoginComponent} from './login/login.component';
import {MatSnackBarModule} from "@angular/material/snack-bar";
import {InquiryRepliedComponent} from './inquiry-replied/inquiry-replied.component';
import {InquiryCanceledComponent} from './inquiry-canceled/inquiry-canceled.component';
import {InquiryRevokedComponent} from './inquiry-revoked/inquiry-revoked.component';
import {CancelComponent} from './cancel/cancel.component';
import {EnInquiryHeaderComponent} from './en-inquiry-header/en-inquiry-header.component';
import {EnInquiryNewComponent} from './en-inquiry-new/en-inquiry-new.component';
import {EnInquiryRepliedComponent} from './en-inquiry-replied/en-inquiry-replied.component';
import {EnLoginComponent} from './en-login/en-login.component';
import {EnInquiryCommonComponent} from './en-inquiry-common/en-inquiry-common.component';
import {EnItemListComponent} from './en-item-list/en-item-list.component';
import {EnItemComponent} from './en-item/en-item.component';
import {EnOtherComponent} from './en-other/en-other.component';
import {EnSendComponent} from './en-send/en-send.component';
import {EnCancelComponent} from './en-cancel/en-cancel.component';
import {EnInquiryCanceledComponent} from './en-inquiry-canceled/en-inquiry-canceled.component';
import {EnInquiryRevokedComponent} from './en-inquiry-revoked/en-inquiry-revoked.component';
import {ContractComponent} from './contract/contract.component';
import {EnContractComponent} from './en-contract/en-contract.component';
import {MessageComponent} from './message/message.component';
import {InquiryMessageComponent} from './inquiry-message/inquiry-message.component';
import {PoSendComponent} from './po-send/po-send.component';
// import {BasicAuthInterceptor} from "./shared/basic-auth.interceptor";
// import {ErrorInterceptor} from "./shared/error.interceptor";


@NgModule({
  declarations: [
    AppComponent,
    AuditFormComponent,
    Notfound404Component,
    FieldErrorDisplayComponent,
    MainPageComponent,
    HelpAuditComponent,
    WelcomeComponent,
    InquiryHeaderComponent,
    InquiryNewComponent,
    InquiryCommonComponent,
    ItemListComponent,
    ItemComponent,
    OtherComponent,
    SendComponent,
    LoginComponent,
    InquiryRepliedComponent,
    InquiryCanceledComponent,
    InquiryRevokedComponent,
    CancelComponent,
    EnInquiryHeaderComponent,
    EnInquiryNewComponent,
    EnInquiryRepliedComponent,
    EnLoginComponent,
    EnInquiryCommonComponent,
    EnItemListComponent,
    EnItemComponent,
    EnOtherComponent,
    EnSendComponent,
    EnCancelComponent,
    EnInquiryCanceledComponent,
    EnInquiryRevokedComponent,
    ContractComponent,
    EnContractComponent,
    MessageComponent,
    InquiryMessageComponent,
    PoSendComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatListModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    MatSnackBarModule,
    // MatTooltipModule,
    // MatButtonModule, MatSelectModule,
    // MatMenuModule
  ],
  providers: [CanDeactivateGuard, RegisterService,
    // { provide: HTTP_INTERCEPTORS, useClass: BasicAuthInterceptor, multi: true },
    // { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
