import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {TotalResponse} from '../shared/models/TotalResponse';
import {CountryService} from '../shared/services/country.service';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {RegisterService} from '../shared/services/register.service';
import {ToastrService} from 'ngx-toastr';

@Component({
  selector: 'app-help-audit',
  templateUrl: './help-audit.component.html',
  styleUrls: ['./help-audit.component.scss']
})
export class HelpAuditComponent implements OnInit {
  countries: [];
  registers : [ { registerNo: string, registerCountry: string} ];
  form: FormGroup = null;
  formId: FormGroup = null;
  formSubmitAttempt = false;
  isWorking= false;

  constructor(private router: Router,
              private countryService: CountryService,
              private toastr: ToastrService,
              private registerService: RegisterService) {
  }

  ngOnInit() {
    this.form = new FormGroup({
      registerNo: new FormControl(null, Validators.required),
      registerCountry: new FormControl('', Validators.required),
      contactPersonEmail: new FormControl('', [Validators.required, Validators.email])
    });
    this.formId = new FormGroup({
      registerId: new FormControl(null, Validators.required),
    });
    this.countryService.getCountry(this).subscribe((data: TotalResponse) => {
      this.countries = data.response.data;
      console.log(this.countries);
    });
  }

  onClickR() {
    this.formSubmitAttempt = true;
    if (this.form.get('registerNo').value && this.form.get('registerCountry').value && this.form.get('contactPersonEmail').value) {
      // this.form.patchValue({countryCallingCode: '93' });
      const criteria= ` ${this.form.get('registerNo').value} , ${this.form.get('registerCountry').value} , ${this.form.get('contactPersonEmail').value} `;
      console.log('criteria=', criteria);
      this.registerService.getRegister(criteria,this).subscribe((x: TotalResponse) => {
        if (x.response.totalRows < 0) {
          this.toastr.warning(" error in sending eMail .",'error',{timeOut: 10000});
        } else
        if (x.response.totalRows > 0) {
          this.toastr.info(
            `  registerNo:${this.form.get('registerNo').value} in Country:${this.findCountry(this.form.get('registerCountry').value)} already registerd in NICICO system. We will contact you by Email.`,
            'info', {timeOut: 10000});
        } else {
          this.toastr.info( " Email sent. please use ID from email in next section and press Continue.");
        }
      });
    }
  }

  onClickR1() {
    // this.formSubmitAttempt = true;
    if (this.formId.get('registerId').value ) {
      // this.form.patchValue({countryCallingCode: '93' });
      const criteria= ` 0 , 0 , 0 , ${this.formId.get('registerId').value} `;
      this.registerService.getRegister(criteria,this).subscribe((x: TotalResponse) => {
        if (x.response.totalRows == 0) {
          this.toastr.warning(" iD IS NOT CORRECT.",'error',{timeOut: 10000});
        } else if (x.response.totalRows == 1) {
          this.registers=x.response.data;
          let r='';
          let c='';
          let id='';
          this.registers.forEach(_ => {
            r=_.registerNo;
            c=_.registerCountry;
          });
          console.log('r,c',r,c);
          this.router.navigate([`audit-form/${this.formId.get('registerId').value}/${c}`]);
        } else {
          this.toastr.info(
            `  already registerd in NICICO system. We will contact you by Email.`,
            'info', {timeOut: 10000});
        }
      });
    }
  }

  findCountry(id) {
    return id;
  }

  onClickB() {
    this.router.navigate(['/']);
  }

  isFieldValid(field: string) {
    return (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSubmitAttempt);
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }
}
