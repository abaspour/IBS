import {Component, OnDestroy, OnInit} from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {ActivatedRoute, Data, Router} from "@angular/router";
import {ToastrService} from "ngx-toastr";
import {TotalResponse} from "../shared/models/TotalResponse";
import {Subscription} from "rxjs";
import {Inquiry} from "../shared/models/inquiry";
import {InquiryService} from "../shared/services/inquiry.service";

export const num2prcision = "^\\d*\\.?\\d{0,2}$";
export const num = "^\\d*$";
export const EnglishAlphabetRegex = '^[a-zA-Z]\\S*$';
export const telRegex = '^[+(]{1}\\d{1,4}[\\s)]{0,1}\\d{1,3}\\s{0,1}\\d{3,15}$';

@Component({
  selector: 'app-cancel',
  templateUrl: './cancel.component.html',
  styleUrls: ['./cancel.component.scss']
})
export class CancelComponent implements OnInit, OnDestroy {

  inquiries: [Inquiry];
  fileData: File = null;
  previewUrl: any = null;
  form: FormGroup = null;
  pageTitle = 'استعلامهای جدید یا مشاهده شده';
  startRow = 1;
  totalRows = 0;
  page = 5;
  endRow = 5;
  errorMessage = '';
  inquiryNumber: string;
  inquiryName: string;
  inquiryDate: string;
  endReplyDate: string;
  filter = false;
  formSubmitAttempt = false;
  isWorking;
  reasons=["1-در حیطه کاری نمی باشد",
    "2-غیر قابل شناسایی بودن کالا (کمبود اطلاعات فنی - مشخصات یا پارت نامبر اشتباه)",
    "3-حجم و یا تعداد کم درخواست ( عدم صرفه اقتصادی)",
    "4-عدم امکان تولید به دلیل کمبود تجهیزات",
    "5-برند کالا در حیطه  فعالیت کاری نمی باشد",
    "6-خط تولید مشغول می باشد",
    "7-عدم تمایل به همکاری",
    "8-به دلیل عدم تسویه حساب درخواستهای قبلی",
    "9-به دلیل تحریمها امکان تامین نمی باشد",
    "10-عدم زمان کافی جهت پاسخدهی به استعلام",
    "11-استعلام تکراری",
    "12-در حال حاضر امکان پاسخدهی نمی باشد",
    "13-به دلیل نوسانات نرخ ارز امکان قیمت دهی نمی باشد",
    "14-عدم موجودی در انبار"
  ];
  criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"supplierId", "operator":"notNull" } ] } `;

  constructor(private router: Router,
              private toastr: ToastrService,
              private activeRouter: ActivatedRoute,
              private inquiryService: InquiryService) {
  }

  ngOnInit() {
    this.form = new FormGroup({
      inquiryNumber: new FormControl(null),
      reason: new FormControl('',Validators.required),
      supDesc: new FormControl(''),
      file__: new FormControl('')
    });
    this.sub=this.activeRouter.params.subscribe((data: Data) => {
      this.inquiryNumber = data.inquiryNumber;
      if (this.inquiryNumber) {
        this.criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"inquiryNumber", "operator":"equals", "value": "${this.inquiryNumber}"  } ] } `;
        this.subscribe(this.criteria + `&_startRow=${this.startRow - 1}&_endRow=${this.endRow}&_sortBy=inquiryNumber`);
      }
    });
  }
  private sub: Subscription;
  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }

  subscribe(criteria) {
    this.inquiryService.getInquiry(criteria,this ).subscribe({
      next: (data: TotalResponse) => {
        this.inquiries = data.response.data;
        this.inquiries.forEach(_ => {
          this.form.patchValue(
            {
              inquiryNumber: _.inquiryNumber,
              supDesc: _.supDesc,
            });
        });
        this.endRow = data.response.endRow;
        this.startRow = data.response.startRow + 1;
        this.totalRows = data.response.totalRows;
      }
      // error : err => this.errorMessage = err
    });

  }

  onClickBack(inq) {
    this.router.navigate([`inquiry-common/${inq}`]);
  }

  isFieldValid(field: string) {
    if (this.form.get(field).valid) {
      return null;
    }
    return (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSubmitAttempt);
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  fileProgress(fileInput: any) {
    this.fileData = <File>fileInput.target.files[0];
    this.preview();
  }

  preview() {
    // Show preview
    const mimeType = this.fileData.type;
    if (mimeType.match(/image\/*/) == null) {
      return;
    }

    let reader = new FileReader();
    reader.readAsDataURL(this.fileData);
    reader.onload = (_event) => {
      this.previewUrl = reader.result;
    };
  }

  onClickNxt() {
    this.formSubmitAttempt = true;
    if (this.form.valid && this.form.dirty) {
      let _ = this.form.getRawValue();
//
      this.inquiries[0].inquiryNumber = _.inquiryNumber;
      this.inquiries[0].supDesc = _.reason+(_.supDesc ? _.supDesc: '');
      this.inquiries[0].verifyStatus = "c";
      this.inquiries[0].changeStatus = "2";
//
      const formData = new FormData();
      formData.append('data', JSON.stringify(this.inquiries[0]));
      if (this.fileData)
         formData.append('file', this.fileData);

      this.inquiryService.updateInquiry(formData,this.inquiries[0].id,this).subscribe(data => {
          this.toastr.success(' پاسخ استعلام با موفقیت ارسال شد.', 'success', {timeOut: 10000});
          setTimeout(() => {
            this.form.reset();
            this.router.navigate([`canceled`]);
          }, 200);
          this.formSubmitAttempt = false;
        }
      );
    } else if (this.form.valid) {
      this.router.navigate([`inquiry`]);
    }
    else {
      this.toastr.error('لطفا نسبت به تکمیل و اصلاح خطا یا خطاها اقدام نمایید.', 'error', {timeOut: 10000});
    }

  }

}
