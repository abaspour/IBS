import {Component, OnInit} from '@angular/core';
import {Router} from "@angular/router";

import {LoginService} from "../shared/services/login.service";
import {ToastrService} from "ngx-toastr";
import {FormContainer} from "../shared/models/ApiHelper";
import {MatSnackBar} from "@angular/material/snack-bar";
import {LocalstorageService} from "../shared/services/localstorage.service";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, FormContainer {

  // variable ha bala bashan
  isWorking: boolean;
  credentials = {username: '', password: ''};
  currentUser;
  error;

  constructor(private loginService: LoginService,
              private matSnackBar: MatSnackBar,
              private router: Router,
              private toastr: ToastrService) {
  }

  login() {
    if (!this.credentials.username || !this.credentials.password ) {
      this.toastr.error('لطفا نسبت به تکمیل فرم اقدام نمایید.', 'error', {timeOut: 10000});
      return;
    }
    this.loginService.login(this.credentials, this).subscribe((x) => {
      console.log(x);
      // this.router.navigateByUrl('inquiry');
      // in mehtod behtar hast emkan ijad query param ro be ma mide
      this.router.navigate(['/inquiry']);
    });

    // return niaz nadare routing dare anjam mishe
  }

  handleError(err) {
    if (err.status === 401) {
      this.matSnackBar.open('نام کاربری یا رمز عبور اشتباه است', '', {
        panelClass: 'error-snack',
        direction: "rtl",
        duration: 3000
      });
    } else {
      this.matSnackBar.open(' خطا در دسترسی', '', {
        panelClass: 'error-snack',
        direction: "rtl",
        duration: 3000
      });
      }
  };

  ngOnInit() {

    // local storage :)
    if (LocalstorageService.getBasicAuth())
      this.currentUser = JSON.parse(LocalstorageService.getBasicAuth());
  }

}
