import {Component, OnInit} from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {ActivatedRoute, Data, Router} from "@angular/router";
import {ToastrService} from "ngx-toastr";
import {InquiryService} from "../shared/services/inquiry.service";
import {TotalResponse} from "../shared/models/TotalResponse";
import {Inquiry} from "../shared/models/inquiry";
import {Subscription} from "rxjs";

@Component({
  selector: 'app-en-inquiry-common',
  templateUrl: './en-inquiry-common.component.html',
  styleUrls: ['./en-inquiry-common.component.scss']
})
export class EnInquiryCommonComponent implements OnInit {

  inquiries : [ Inquiry ];
  form: FormGroup = null;
  startRow = 1;
  totalRows = 0;
  page =5;
  endRow = 5;
  errorMessage = '';
  inquiryNumber: string;
  inquiryName: string;
  inquiryDate: string;
  endReplyDate: string;
  filter = false;
  formSubmitAttempt = false;
  criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"supplierId", "operator":"notNull"  } ] } `;
  constructor(private router: Router,
              private activeRouter: ActivatedRoute,
              private toastr: ToastrService,
              private inquiryService: InquiryService) {
  }

  ngOnInit() {
    this.form = new FormGroup({
      inquiryNumber: new FormControl(null, Validators.required),
      inquiryName: new FormControl('', Validators.required),
      inquiryDate: new FormControl('', Validators.required),
      endReplyDate: new FormControl('', Validators.required)
    });
    this.sub=this.activeRouter.params.subscribe((data: Data) => {
      this.inquiryNumber = data.inquiryNumber;
      if (this.inquiryNumber) {
        this.criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"inquiryNumber", "operator":"equals", "value": "${this.inquiryNumber}"  } ] } `;
        this.subscribe(this.criteria + `&_startRow=${this.startRow - 1}&_endRow=${this.endRow}&_sortBy=-endReplyDate`);
      }
    } );
  }
  private sub: Subscription;
  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }

  subscribe(criteria){
    this.inquiryService.getInquiry(criteria,this).subscribe({
      next: (data: TotalResponse) => {
        this.inquiries = data.response.data;
        this.endRow=data.response.endRow;
        this.startRow=data.response.startRow+1;
        this.totalRows=data.response.totalRows;
        this.onShow();
      }
      // error : err => this.errorMessage = err
    });

  }

  onShow(){
    if (this.inquiries[0].verifyStatus === 'n'){
      this.inquiryService.updateInquiryStatus(this.inquiryNumber,this).subscribe({
        next: (data: number) => {
          console.log('status changed:', data);
        }
      })
    }
  }


  onClickNxt(){
    this.router.navigate([`enItem-list/${this.inquiryNumber}`]);
  }
  onClickCancel(){
    this.router.navigate([`enCancel/${this.inquiryNumber}`]);
  }
  onClickSerchClr(){
    this.inquiryNumber='';
    this.inquiryName='';
    this.inquiryDate='';
    this.endReplyDate='';
    this.onClickSerch();
  }
  onClickSerch(){
    this. criteria = `{ "operator":"and", "criteria" : [   { "fieldName":"supplierId", "operator":"notNull"  } `;
    this.filter = false;
    if (this.inquiryNumber) {
      this.filter = true;
      this.criteria += `,{ "fieldName":"inquiryNumber", "operator":"iContains", "value": "${this.inquiryNumber}"  } `;
    }
    if (this.inquiryName){
      this.filter = true;
      this.criteria += `,{ "fieldName":"inquiryName", "operator":"iContains", "value": "${this.inquiryName}"  } `;
    }
    if (this.inquiryDate){
      this.filter = true;
      this.criteria += `,{ "fieldName":"inquiryDate", "operator":"iContains", "value": "${this.inquiryDate}"  } `;
    }
    if (this.endReplyDate){
      this.filter = true;
      this.criteria += `,{ "fieldName":"endReplyDate", "operator":"iContains", "value": "${this.endReplyDate}"  } `;
    }
    this.criteria += `] } `;
    this.startRow = 1;
    this.endRow = this.page;
    this.subscribe(this.criteria+ `&_startRow=${this.startRow-1}&_endRow=${this.endRow}&_sortBy=-endReplyDate`);

  }
  onClickB() {
    this.router.navigate(['/enInquiry']);
  }

  isFieldValid(field: string) {
    return (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSubmitAttempt);
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

}
