import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {EnCancelComponent} from './en-cancel.component';

describe('EnCancelComponent', () => {
  let component: EnCancelComponent;
  let fixture: ComponentFixture<EnCancelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnCancelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnCancelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
