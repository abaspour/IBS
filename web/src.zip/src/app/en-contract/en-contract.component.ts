import {Component, OnInit} from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import {ToastrService} from "ngx-toastr";
import {ContractService} from "../shared/services/contract.service";
import {TotalResponse} from "../shared/models/TotalResponse";
import {Contract} from "../shared/models/contract";

@Component({
  selector: 'app-en-contract',
  templateUrl: './en-contract.component.html',
  styleUrls: ['./en-contract.component.scss']
})
export class EnContractComponent implements OnInit {


  contracts: [Contract];
  isWorking = false;
  form: FormGroup = null;
  pageTitle = 'Contracts';
  startRow = 1;
  totalRows = 0;
  page = 5;
  endRow = 5;
  errorMessage = '';
  purchaseOrder: string;
  dsc: string;
  filter = false;
  formSubmitAttempt = false;
  criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"supplierId", "operator":"notNull"  } ] } `;

  constructor(private router: Router,
              private toastr: ToastrService,
              private contractService: ContractService) {
  }

  ngOnInit() {
    this.form = new FormGroup({
      purchaseOrder: new FormControl(null, Validators.required),
      dsc: new FormControl('', Validators.required),
      contractDate: new FormControl('', Validators.required),
      endReplyDate: new FormControl('', Validators.required)
    });

    this.subscribe(this.criteria + `&_startRow=${this.startRow - 1}&_endRow=${this.endRow}&_sortBy=-purchaseOrder`);
  }

  subscribe(criteria) {
    this.contractService.getContract(criteria, this).subscribe({
      next: (data: TotalResponse) => {
        this.contracts = data.response.data;
        this.endRow = data.response.endRow;
        this.startRow = data.response.startRow + 1;
        this.totalRows = data.response.totalRows;
      }
      // error : err => this.errorMessage = err
    });

  }

  onClickPrv() {
    if (this.startRow != 1) {
      this.endRow = this.startRow - 1;
      this.startRow = (this.startRow - this.page > 0) ? this.startRow - this.page : 1;
      this.subscribe(this.criteria + `&_startRow=${this.startRow - 1}&_endRow=${this.endRow}&_sortBy=-purchaseOrder`);
    }
  }

  onClickNxt() {
    if (this.endRow != this.totalRows) {
      this.startRow = this.endRow + 1;
      this.endRow = (this.endRow + this.page <= this.totalRows) ? this.endRow + this.page : this.totalRows;
      this.subscribe(this.criteria + `&_startRow=${this.startRow - 1}&_endRow=${this.endRow}&_sortBy=-purchaseOrder`);
    }
  }

  onClickSerchClr() {
    this.purchaseOrder = '';
    this.dsc = '';
    this.onClickSerch();
  }

  onClickSerch() {
    this.criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"supplierId", "operator":"notNull"  } `;
    this.filter = false;
    if (this.purchaseOrder) {
      this.filter = true;
      this.criteria += `,{ "fieldName":"purchaseOrder", "operator":"iContains", "value": "${this.purchaseOrder}"  } `;
    }
    if (this.dsc) {
      this.filter = true;
      this.criteria += `,{ "fieldName":"dsc", "operator":"iContains", "value": "${this.dsc}"  } `;
    }
    this.criteria += `] } `;
    this.startRow = 1;
    this.endRow = this.page;
    this.subscribe(this.criteria + `&_startRow=${this.startRow - 1}&_endRow=${this.endRow}&_sortBy=-purchaseOrder`);

  }

  onClickB() {
    this.router.navigate(['/']);
  }

  isFieldValid(field: string) {
    return (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSubmitAttempt);
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }


  download(urll): void {
    this.contractService.download(urll).subscribe(blob => {
      const a = document.createElement('a')
      const objectUrl = URL.createObjectURL(blob)
      a.href = objectUrl
      a.download = 'file';
      a.click();
      URL.revokeObjectURL(objectUrl);
    });
  }

}
