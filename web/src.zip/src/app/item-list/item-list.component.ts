import {Component, OnDestroy, OnInit} from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {ActivatedRoute, Data, Router} from "@angular/router";
import {ToastrService} from "ngx-toastr";
import {TotalResponse} from "../shared/models/TotalResponse";
import {RegisterPrice} from "../shared/models/register-price";
import {RegisterPriceService} from "../shared/services/register-price.service";
import {Subscription} from "rxjs";

@Component({
  selector: 'app-item-list',
  templateUrl: './item-list.component.html',
  styleUrls: ['./item-list.component.scss']
})
export class ItemListComponent implements OnInit, OnDestroy {

  registerPrices : [ RegisterPrice ];
  form: FormGroup = null;
  pageTitle = 'استعلامهای جدید یا مشاهده شده';
  startRow = 1;
  totalRows = 0;
  page =5;
  endRow = 5;
  errorMessage = '';
  inquiryNumber: string;
  inquiryName: string;
  inquiryDate: string;
  endReplyDate: string;
  filter = false;
  formSubmitAttempt = false;
  criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"supplierId", "operator":"notNull"  } ] } `;
  constructor(private router: Router,
              private toastr: ToastrService,
              private activeRouter: ActivatedRoute,
              private registerPriceService: RegisterPriceService) {
  }

  ngOnInit() {
    this.form = new FormGroup({
      inquiryNumber: new FormControl(null, Validators.required),
      inquiryName: new FormControl('', Validators.required),
      inquiryDate: new FormControl('', Validators.required),
      endReplyDate: new FormControl('', Validators.required)
    });
    this.sub=this.activeRouter.params.subscribe((data: Data) => {
      this.inquiryNumber = data.inquiryNumber;
      if (this.inquiryNumber) {
        this.criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"inquiryNumber", "operator":"equals", "value": "${this.inquiryNumber}"  } ] } `;
        this.subscribe(this.criteria + `&_startRow=${this.startRow - 1}&_endRow=${this.endRow}&_sortBy=itemRow`);
      }
    } );
  }
  private sub: Subscription;
  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }
  subscribe(criteria){
    this.registerPriceService.getRegisterPrice(criteria,this).subscribe({
      next: (data: TotalResponse) => {
        this.registerPrices = data.response.data;
        this.endRow=data.response.endRow;
        this.startRow=data.response.startRow+1;
        this.totalRows=data.response.totalRows;
      }
      // error : err => this.errorMessage = err
    });

  }
  onClickPrv(){
    if (this.startRow!=1) {
      this.endRow=this.startRow -1;
      this.startRow=(this.startRow-this.page > 0) ? this.startRow-this.page : 1 ;
      this.subscribe(this.criteria+ `&_startRow=${this.startRow-1}&_endRow=${this.endRow}&_sortBy=-endReplyDate`);
    }
  }
  onClickNxt(){
    let p=0;
    this.registerPrices.forEach(_ => {
      if (Number(_.gheymateKol))
        p += Number(_.gheymateKol);
    });
    if (p<=10) {
      this.toastr.error('لطفا نسبت به قیمت دهی به قلم یا اقلام اعلامی اقدام فرمایید.',
        'error', {timeOut: 5000});
    } else {
      this.router.navigate([`other/${this.inquiryNumber}`]);
    }
  }

  onClickB() {
    this.router.navigate([`inquiry-common/${this.inquiryNumber}`]);
  }

  onClickItem(registerPriceId) {
    this.router.navigate([`item/${registerPriceId}`]);
  }

  isFieldValid(field: string) {
    return (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSubmitAttempt);
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }
  download(urll): void {
    this.registerPriceService.download(urll).subscribe(blob => {
      const a = document.createElement('a')
      const objectUrl = URL.createObjectURL(blob)
      a.href = objectUrl
      a.download = 'file';
      a.click();
      URL.revokeObjectURL(objectUrl);
    });
  }
}
