import {Component, OnInit} from '@angular/core';
import {Router} from "@angular/router";
import {LocalstorageService} from "../shared/services/localstorage.service";
import {InquiryService} from "../shared/services/inquiry.service";

@Component({
  selector: 'app-en-inquiry-header',
  templateUrl: './en-inquiry-header.component.html',
  styleUrls: ['./en-inquiry-header.component.scss']
})
export class EnInquiryHeaderComponent implements OnInit {
  currentUser;
  criteria = "";
  startRow=0;
  endRow=100;
  isWorking="";
  nc = 0;  //جدید= contract
  vc = 0;  //مشاهده شده =contract
  nn=0;  //جدید=
  vv=0;  //مشاهده شده =
  rr=0;  //پاسخ داده شده =
  cc=0;  //انصراف داده شده =
  ff=0;  //ابطال شده =
  contract_n = 0;
  contract_v = 0;
  message_n = 0;
  message_y = 0;
  showCombo=false;

  constructor(private router: Router,
              private inquiryService: InquiryService) { }

  ngOnInit() {
    if (LocalstorageService.getBasicAuth())
      this.currentUser=JSON.parse(LocalstorageService.getBasicAuth());
    this.criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"supplierId", "operator":"equals", "value": "${this.currentUser.supplierId}"  } ] } `;
    this.subscribe( this.criteria + `&_startRow=${this.startRow-1}&_endRow=${this.endRow}&_sortBy=-endReplyDate` );
  }

  subscribe(criteria) {
    this.inquiryService.getInquiryCount(this).subscribe({
      next: (data1:Counts) => {
        let data=data1.data;
        data.forEach(r => {
          if (r.status==='n')
            this.nn=r.count;
          if (r.status==='v')
            this.vv=r.count;
          if (r.status==='r')
            this.rr=r.count;
          if (r.status === 'c')
            this.cc = r.count * 1 + this.cc * 1;
          if (r.status === 'f')
            this.ff = r.count;
          if (r.status === 'contract_n')
            this.contract_n = r.count;
          if (r.status === 'contract_v')
            this.contract_v = r.count;
          if (r.status === 'message_n')
            this.message_n = r.count;
          if (r.status === 'message_y')
            this.message_y = r.count;
        });
        if (data)
          this.showCombo=true;
        //    console.log(data);
      }
      // error : err => this.errorMessage = err
    });
  }
  onClickLogoff(){
    LocalstorageService.clearAll();
    this.router.navigate(['/']);
  }
}
export interface Counts {
  data :[{
    count: number;
    status: string;
  }]
}
