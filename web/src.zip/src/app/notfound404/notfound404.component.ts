import {Component, OnInit} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {Subscription} from 'rxjs';

@Component({
  selector: 'app-notfound404',
  templateUrl: './notfound404.component.html',
  styleUrls: ['./notfound404.component.scss']
})
export class Notfound404Component implements OnInit {

  constructor(private router: ActivatedRoute) {
  }

  messgae;
  subcrition: Subscription;

  ngOnInit() {
    this.subcrition = this.router.data.subscribe((data) => {
      this.messgae = data[0].message;
    })
  }

}
