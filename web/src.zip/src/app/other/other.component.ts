import {AfterViewInit, Component, ElementRef, OnDestroy, OnInit, ViewChildren} from '@angular/core';
import {AbstractControl, FormControl, FormControlName, FormGroup, ValidationErrors, Validators} from "@angular/forms";
import {ActivatedRoute, Data, Router} from "@angular/router";
import {ToastrService} from "ngx-toastr";
import {RegisterPriceHeaderService} from "../shared/services/register-price-header.service";
import {TotalResponse} from "../shared/models/TotalResponse";
import {fromEvent, merge, Observable, Subscription} from "rxjs";
import {debounceTime} from "rxjs/operators";
import {RegisterPriceHeader} from "../shared/models/register-price-header";

export const num2prcision = "^\\d*\\.?\\d{0,2}$";
export const num = "^\\d*$";
export const EnglishAlphabetRegex = '^[a-zA-Z]\\S*$';
export const telRegex = '^[+(]{1}\\d{1,4}[\\s)]{0,1}\\d{1,3}\\s{0,1}\\d{3,15}$';

@Component({
  selector: 'app-other',
  templateUrl: './other.component.html',
  styleUrls: ['./other.component.scss']
})
export class OtherComponent implements OnInit, AfterViewInit, OnDestroy {

  @ViewChildren(FormControlName, {read: ElementRef}) formInputElements: ElementRef[];

  registerPricesHeader: [RegisterPriceHeader];
  fileData: File = null;
  previewUrl: any = null;
  form: FormGroup = null;
  pageTitle = 'استعلامهای جدید یا مشاهده شده';
  startRow = 1;
  totalRows = 0;
  page = 5;
  endRow = 5;
  errorMessage = '';
  inquiryNumber: string;
  inquiryName: string;
  inquiryDate: string;
  endReplyDate: string;
  filter = false;
  formSubmitAttempt = false;

  criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"supplierId", "operator":"notNull" } ] } `;

  constructor(private router: Router,
              private toastr: ToastrService,
              private activeRouter: ActivatedRoute,
              private registerPriceHeaderService: RegisterPriceHeaderService) {
  }

  ngOnInit() {
    this.form = new FormGroup({
      inquiryNumber: new FormControl(null),
      sumPrincipal: new FormControl('', [Validators.required, Validators.min(0), Validators.max(10000000001), this.regexValidator(new RegExp(num), {en: 'en'})]),
      portage: new FormControl(''),
      portageCost: new FormControl('', [Validators.required, Validators.min(0), Validators.max(10000000001), this.regexValidator(new RegExp(num), {en: 'en'})]),
      packingCost: new FormControl('', [Validators.required, Validators.min(0), Validators.max(10000000001), this.regexValidator(new RegExp(num), {en: 'en'})]),
      otherCost: new FormControl('', [Validators.required, Validators.min(0), Validators.max(10000000001), this.regexValidator(new RegExp(num), {en: 'en'})]),
      otherCostRequire: new FormControl(''),
      subInstallCost: new FormControl('', [Validators.required, Validators.min(0), Validators.max(10000000001), this.regexValidator(new RegExp(num), {en: 'en'})]),
      installCostRequire: new FormControl(''),
      subSpareProductCost: new FormControl(''),
      spareProductFileName: new FormControl(''),
      discount: new FormControl('', [Validators.required, Validators.min(0), Validators.max(10000000001), this.regexValidator(new RegExp(num), {en: 'en'})]),
      taxCost: new FormControl('',Validators.required),
      taxCostValue: new FormControl('',Validators.required),
      sumPrice: new FormControl('',Validators.required),
      checkInfo: new FormControl(''),
      file_: new FormControl(''),
      spareProductTime: new FormControl('')
    });
    // this.form.get('priceBeforeDiscount').disable()
    // this.form.get('gheymateKol').disable()
    this.sub=this.activeRouter.params.subscribe((data: Data) => {
      this.inquiryNumber = data.inquiryNumber;
      if (this.inquiryNumber) {
        this.criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"id", "operator":"equals", "value": "${this.inquiryNumber}"  } ] } `;
        this.subscribe(this.criteria + `&_startRow=${this.startRow - 1}&_endRow=${this.endRow}&_sortBy=inquiryNumber`);
      }
    });
  }
  private sub: Subscription;
  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }
  ngAfterViewInit(): void {
    // Watch for the blur event from any input element on the form.
    // This is required because the valueChanges does not provide notification on blur
    const controlBlurs: Observable<any>[] = this.formInputElements
      .map((formControl: ElementRef) => fromEvent(formControl.nativeElement, 'blur'));

    // Merge the blur event observable with the valueChanges observable
    // so we only need to subscribe once.
    merge(this.form.valueChanges, ...controlBlurs).pipe(
      debounceTime(800)
    ).subscribe(value => {
      this.calculatePricesItem();
    });
  }

  subscribe(criteria) {
     this.registerPriceHeaderService.getRegisterPriceHeader(criteria,this).subscribe({
      next: (data: TotalResponse) => {
        this.registerPricesHeader = data.response.data;
        this.registerPricesHeader.forEach(_ => {
          this.form.patchValue(
            {
              inquiryNumber: _.inquiryNumber,
              sumPrincipal: _.sumPrincipal,
              portage: _.portage,
              portageCost: _.portageCost,
              packingCost: _.packingCost,
              otherCostRequire: _.otherCostRequire,
              otherCost: _.otherCost,
              installCostRequire: _.installCostRequire,
              subInstallCost: _.subInstallCost,
              subSpareProductCost: _.subSpareProductCost,
              spareProductFileName: _.spareProductFileName,
              discount: _.discount,
              taxCost: _.taxCost,
              taxCostValue: _.taxCostValue,
              sumPrice: _.sumPrice,
              checkInfo: _.checkInfo,
              spareProductTime: _.spareProductTime
            });
          if (_.spareProductTime && _.spareProductTime < '0' && _.inquiryType == 's') {
            this.form.get("subSpareProductCost").setValidators([Validators.required, Validators.min(0), Validators.max(10000000001), this.regexValidator(new RegExp(num), {en: 'en'})]);
            this.form.get("subSpareProductCost").updateValueAndValidity();
          }
          if (_.inquiryType && _.inquiryType == 's') {
            this.form.get("checkInfo").setValidators([Validators.required]);
            this.form.get("checkInfo").updateValueAndValidity();
          }
          if (_.spareProductTime && _.spareProductTime >'0' && !_.spareProductFileName) {
            this.form.get("file_").setValidators([Validators.required]);
            this.form.get("file_").updateValueAndValidity();
          }

        });
        this.endRow = data.response.endRow;
        this.startRow = data.response.startRow + 1;
        this.totalRows = data.response.totalRows;
      }
      // error : err => this.errorMessage = err
    });

  }

  onClickBack(inq) {
    this.router.navigate([`item-list/${inq}`]);
  }

  isFieldValid(field: string) {
    if (this.form.get(field).valid) {
      return null;
    }
    return (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSubmitAttempt);
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }
  fileCss() {
     let vali= false;
     if (!this.form.get('spareProductTime') || this.form.get('spareProductTime').value <'0'  || this.form.get('spareProductFileName').value || this.fileData!=null)
       vali=true;
     console.log('css=',vali)
    return {
      'has-error': !vali,
      'has-feedback': vali
    }
  }

  fileProgress(fileInput: any) {
    this.fileData = <File>fileInput.target.files[0];
    this.preview();
  }

  preview() {
    // Show preview
    const mimeType = this.fileData.type;
    if (mimeType.match(/image\/*/) == null) {
      return;
    }

    let reader = new FileReader();
    reader.readAsDataURL(this.fileData);
    reader.onload = (_event) => {
      this.previewUrl = reader.result;
    };
  }

  onClickNxt() {
    this.calculatePricesItem();
    if (this.registerPricesHeader[0].inquiryType=='s' && !this.form.get('checkInfo').value) {
      this.toastr.error('لطفا "شرایط عمومی را مشاهده کردم و قبول دارم" را  تیک بزنید.',
        'error', {timeOut: 5000});
      this.formSubmitAttempt = false;
      return;
    }
    this.formSubmitAttempt = true;
    if (this.form.valid && this.form.dirty) {
      let _ = this.form.getRawValue();
      this.registerPricesHeader[0].inquiryNumber = _.inquiryNumber;
      this.registerPricesHeader[0].sumPrincipal = _.sumPrincipal;
      this.registerPricesHeader[0].  portage=  _.portage;
      this.registerPricesHeader[0].portageCost=  _.portageCost;
      this.registerPricesHeader[0].packingCost=  _.packingCost;
      this.registerPricesHeader[0].otherCostRequire=  _.otherCostRequire;
      this.registerPricesHeader[0].otherCost=  _.otherCost;
      this.registerPricesHeader[0].installCostRequire=  _.installCostRequire;
      this.registerPricesHeader[0].subInstallCost=  _.subInstallCost;
      this.registerPricesHeader[0].subSpareProductCost=  _.subSpareProductCost;
      this.registerPricesHeader[0].spareProductFileName=  _.spareProductFileName;
      this.registerPricesHeader[0].discount=  _.discount;
      this.registerPricesHeader[0].taxCost=  _.taxCost;
      this.registerPricesHeader[0].taxCostValue=  _.taxCostValue;
      this.registerPricesHeader[0].sumPrice=  _.sumPrice;
      this.registerPricesHeader[0].checkInfo=  _.checkInfo;
      this.registerPricesHeader[0].spareProductTime=  _.spareProductTime;
//

      const formData = new FormData();
      formData.append('data', JSON.stringify(this.registerPricesHeader[0]));
      if (this.registerPricesHeader[0].spareProductTime && this.registerPricesHeader[0].spareProductTime > '0') {
        formData.append('file', this.fileData);
      } else {
        formData.append('file', null);
      }

      this.registerPriceHeaderService.updateRegisterPriceHeader(formData,
        this.registerPricesHeader[0].id,this).subscribe(data => {
          this.toastr.success(' با موفقیت ذخبره شد.', 'success', {timeOut: 10000});
          setTimeout(() => {
            this.form.reset();
            this.router.navigate([`send/${this.registerPricesHeader[0].inquiryNumber}`]);
          }, 200);
          this.formSubmitAttempt = false;
        },
        error => {
          this.toastr.error(' Error .' + JSON.stringify(error.error), 'Error', {timeOut: 10000});
          setTimeout(() => {
            // this.router.navigate(['/']);
          }, 20000);
        }
      );
    } else if (this.form.valid) {
      this.router.navigate([`send/${this.registerPricesHeader[0].inquiryNumber}`]);
    }
    else {
      this.toastr.error('لطفا نسبت به تکمیل و اصلاح خطا یا خطاها اقدام نمایید.', 'error', {timeOut: 10000});
      // console.log('companyActivity', this.register.companyActivity);
      // alert('same error/s on page');
    }

  }

  regexValidator(regex: RegExp, error: ValidationErrors) {
    return (control: AbstractControl): { [key: string]: any } => {
      if (!control.value) {
        return null;
      }
      const valid = regex.test(control.value);
      console.log(valid)
      return valid ? null : error;
    };
  }
  calculatePricesItem() {
    let sumPrincipal=0;
    let portageCost = 0;
    let packingCost = 0;
    let subspareCost = 0;
    let otherCost = 0;
    let discount = 0;
    let	subInstallCost = 0;
    let taxPercent = 0;
    let taxCostValue=0;
    let totlaPrice = 0;

    if (this.form.get('sumPrincipal').valid && this.form.get('sumPrincipal').value)
      sumPrincipal = this.form.get('sumPrincipal').value;
    if (this.form.get('portageCost').valid && this.form.get('portageCost').value)
      portageCost = this.form.get('portageCost').value;
    if (this.form.get('packingCost').valid != null && this.form.get('packingCost').value)
      packingCost = this.form.get('packingCost').value;
    if (this.form.get('subSpareProductCost').valid != null && this.form.get('subSpareProductCost').value)
      subspareCost = this.form.get('subSpareProductCost').value;
    if (this.form.get('otherCost').valid != null && this.form.get('otherCost').value)
      otherCost = this.form.get('otherCost').value;
    if (this.form.get('discount').valid != null && this.form.get('discount').value)
      discount = this.form.get('discount').value;
    if (this.form.get('taxCost').valid != null && this.form.get('taxCost').value)
      taxPercent = this.form.get('taxCost').value;
    if (this.form.get('subInstallCost').valid != null && this.form.get('subInstallCost').value)
      subInstallCost = this.form.get('subInstallCost').value;

    totlaPrice = sumPrincipal*1+portageCost*1 +packingCost*1+ subspareCost*1 + otherCost*1 + subInstallCost*1 - discount*1;
    taxCostValue = Math.round(totlaPrice*taxPercent*1/100);
    totlaPrice=totlaPrice+taxCostValue;
    if (taxCostValue!=this.form.get('taxCostValue').value || totlaPrice*1!=this.form.get('sumPrice').value  ) {
      this.form.patchValue({'taxCostValue': taxCostValue, 'sumPrice': totlaPrice*1});
      console.log('pached');
    }
  };

  // download(urll): void {
  //   this.registerPriceService.download(urll).subscribe(response => {
  //     let blob: any = new Blob([response], {type: 'text/json; charset=utf-8'});
  //     const url = window.URL.createObjectURL(blob);
  //     window.open(url);
  //     // window.location.href = response.url;
  //     //fileSaver.saveAs(blob, 'employees.json');
  //   }), error => console.log('Error downloading the file'),
  //     () => console.info('File downloaded successfully');
  // }

  download(urll): void {
    this.registerPriceHeaderService.download(urll).subscribe(blob => {
      const a = document.createElement('a')
      const objectUrl = URL.createObjectURL(blob)
      a.href = objectUrl
      a.download = 'file';
      a.click();
      URL.revokeObjectURL(objectUrl);
    });
  }


}
