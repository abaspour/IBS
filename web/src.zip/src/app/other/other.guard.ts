import {Injectable} from '@angular/core';
import {CanDeactivate} from '@angular/router';
import {Observable} from 'rxjs';
import {OtherComponent} from "./other.component";


@Injectable({
  providedIn: 'root'
})
export class OtherGuard implements CanDeactivate<OtherComponent> {
  canDeactivate(component: OtherComponent): Observable<boolean> | Promise<boolean> | boolean {
    if (component.form.dirty) {
      const countryName = component.form.get('inquiryNumber').value || ' می گردد. مطمئن هستید؟ ';
      return confirm(`خروج از صفحه باعث عدم ذخیره تغییرات داده شده برای استعلام ${countryName}?`);
    }
    return true;
  }
}

