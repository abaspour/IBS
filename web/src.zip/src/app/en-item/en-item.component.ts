import {Component, ElementRef, OnInit, ViewChildren} from '@angular/core';
import {AbstractControl, FormControl, FormControlName, FormGroup, ValidationErrors, Validators} from "@angular/forms";
import {ActivatedRoute, Data, Router} from "@angular/router";
import {ToastrService} from "ngx-toastr";
import {TotalResponse} from "../shared/models/TotalResponse";
import {CountryService} from "../shared/services/country.service";
import {Country} from "../country";
import {fromEvent, merge, Observable, Subscription} from "rxjs";
import {debounceTime} from "rxjs/operators";
import {ProformItem} from "../shared/models/ProformItem";
import {ProformItemService} from "../shared/services/proform-item.service";
import {Unit} from "../shared/models/Unit";
import {UnitService} from "../shared/services/unit.service";
import {CurrencyService} from "../shared/services/currency.service";
import {Currency} from "../shared/models/Currency";

export const num2prcision = "^\\d*\\.?\\d{0,2}$";
export const num = "^\\d*$";
export const EnglishAlphabetRegex = '^[a-zA-Z]\\S*$';
export const telRegex = '^[+(]{1}\\d{1,4}[\\s)]{0,1}\\d{1,3}\\s{0,1}\\d{3,15}$';

@Component({
  selector: 'app-en-item',
  templateUrl: './en-item.component.html',
  styleUrls: ['./en-item.component.scss']
})
export class EnItemComponent implements OnInit {
  @ViewChildren(FormControlName, {read: ElementRef}) formInputElements: ElementRef[];

  proformItems: [ProformItem];
  countries: [Country];
  units: [Unit];
  currencies: [Currency];
  fileData: File = null;
  previewUrl: any = null;
  form: FormGroup = null;
  pageTitle = 'استعلامهای جدید یا مشاهده شده';
  startRow = 1;
  totalRows = 0;
  page = 5;
  endRow = 5;
  errorMessage = '';
  id: string;
  filter = false;
  formSubmitAttempt = false;

  criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"supplierId", "operator":"notNull"} ] } `;

  constructor(private router: Router,
              private toastr: ToastrService,
              private activeRouter: ActivatedRoute,
              private countryService: CountryService,
              private unitService: UnitService,
              private currencyService: CurrencyService,
              private proformItemService: ProformItemService) {
  }

  ngOnInit() {
    this.form = new FormGroup({
      constructorName: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(200)]),
      amount: new FormControl('', [Validators.required, Validators.min(0), Validators.max(10000001), this.regexValidator(new RegExp(num2prcision), {en: 'en'})]),
      unitId: new FormControl('', [Validators.required, Validators.min(0), Validators.max(10000000001), this.regexValidator(new RegExp(num), {en: 'en'})]),
      currencyId: new FormControl('', [Validators.required, Validators.min(0), Validators.max(10000000001), this.regexValidator(new RegExp(num), {en: 'en'})]),
      price: new FormControl('', [Validators.required, Validators.min(0), Validators.max(10000001), this.regexValidator(new RegExp(num2prcision), {en: 'en'})]),
      countryByConstructureId: new FormControl(null, [Validators.required]),
      verifyPrice: new FormControl(null,Validators.required),
      itemDescription: new FormControl(''),
    });
    this.sub = this.activeRouter.params.subscribe((data: Data) => {
      this.id = data.id;
      if (this.id) {
        this.criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"id", "operator":"equals", "value": "${this.id}"  } ] } `;
        this.subscribe(this.criteria + `&_startRow=${this.startRow - 1}&_endRow=${this.endRow}&_sortBy=id`);
        this.countryService.getCountry(this).subscribe(
          (data: TotalResponse) => this.countries = data.response.data
        );
        let criteriaa = `{ "operator":"and", "criteria" : [  { "fieldName":"isActive", "operator":"equals", "value": "y"  } ] }&_startRow=0&_endRow=2000&_sortBy=nameFa`;
        this.unitService.getUnit(criteriaa,this).subscribe(
          (data: TotalResponse) => this.units = data.response.data
        );
        criteriaa = `{ "operator":"and", "criteria" : [  { "fieldName":"isActive", "operator":"equals", "value": "y"  } ] }&_startRow=0&_endRow=2000&_sortBy=nameEn`;
        this.currencyService.getCurrency(criteriaa,this).subscribe(
          (data: TotalResponse) => this.currencies = data.response.data
        );
      }
    });
  }

  private sub: Subscription;

  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }

  ngAfterViewInit(): void {
    // Watch for the blur event from any input element on the form.
    // This is required because the valueChanges does not provide notification on blur
    const controlBlurs: Observable<any>[] = this.formInputElements
      .map((formControl: ElementRef) => fromEvent(formControl.nativeElement, 'blur'));

    // Merge the blur event observable with the valueChanges observable
    // so we only need to subscribe once.
    merge(this.form.valueChanges, ...controlBlurs).pipe(
      debounceTime(800)
    ).subscribe(value => {
      this.calculatePricesItem();
    });
  }
  subscribe(criteria) {
    this.form.get('verifyPrice').valueChanges.subscribe(_ => {
      if (_ == 'nv') {
        this.form.get("itemDescription").setValidators([Validators.required]);
      } else {
        this.form.get("itemDescription").clearValidators();
      }
      this.form.get("itemDescription").updateValueAndValidity();
    });
    this.proformItemService.getProformItem(criteria,this).subscribe({
      next: (data: TotalResponse) => {
        this.proformItems = data.response.data;
        this.proformItems.forEach(_ => {
          this.form.patchValue(
            {
              constructorName: _.constructorName,
              amount: _.amount,
              unitId:_.unit.id,
              currencyId:_.proform.currencyId,
              price: _.price,
              countryByConstructureId: _.countryByConstructure ? _.countryByConstructure.id : null,
              verifyPrice: _.verifyPrice,
              itemDescription: _.itemDescription
            });

          if (_.verifyPrice && _.verifyPrice == 'nv') {
            this.form.get("itemDescription").setValidators([Validators.required]);
            this.form.get("itemDescription").updateValueAndValidity();
          }
        });
        this.endRow = data.response.endRow;
        this.startRow = data.response.startRow + 1;
        this.totalRows = data.response.totalRows;
      }
      // error : err => this.errorMessage = err
    });

  }
  onClickBack(inq) {
    this.router.navigate([`enItem-list/${inq}`]);
  }

  isFieldValid(field: string) {
    if (this.form.get(field).valid) {
      return null;
    }
    return (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSubmitAttempt);
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  fileProgress(fileInput: any) {
    this.fileData = <File>fileInput.target.files[0];
    this.preview();
  }

  preview() {
    // Show preview
    const mimeType = this.fileData.type;
    if (mimeType.match(/image\/*/) == null) {
      return;
    }

    let reader = new FileReader();
    reader.readAsDataURL(this.fileData);
    reader.onload = (_event) => {
      this.previewUrl = reader.result;
    };
  }

  onClickNxt() {
    this.calculatePricesItem();
    this.formSubmitAttempt = true;
    if (this.form.valid && this.form.dirty) {
      let _ = this.form.getRawValue();
      this.proformItems[0].constructorName = _.constructorName;
      this.proformItems[0].amount = _.amount;
      this.proformItems[0].unitId = _.unitId;
      this.proformItems[0].price = _.price;
      this.proformItems[0].countryByConstructureId =  _.countryByConstructureId;
      this.proformItems[0].verifyPrice = _.verifyPrice;
      this.proformItems[0].itemDescription = _.itemDescription;
      this.proformItems[0].currencyId = _.currencyId;
//
      const formData = new FormData();
      formData.append('data', JSON.stringify(this.proformItems[0]));
      formData.append('file', this.fileData);

      this.proformItemService.updateProformItem(formData, this.proformItems[0].id,this).subscribe(data => {
          this.toastr.success(' saved.', 'success', {timeOut: 10000});
          setTimeout(() => {
            this.form.reset();
            this.onClickBack(this.proformItems[0].proform.inquiryNumber);
          }, 20);
          this.formSubmitAttempt = false;
        },
        error => {
          this.toastr.error(' Error .' + JSON.stringify(error.error), 'Error', {timeOut: 10000});
          setTimeout(() => {
            // this.router.navigate(['/']);
          }, 20000);
        }
      );
    } else if (this.form.valid) {
      this.onClickBack(this.proformItems[0].proform.inquiryNumber);
    } else {
      this.toastr.error('Please fix error(s).', 'error', {timeOut: 10000});
    }

  }

  regexValidator(regex: RegExp, error: ValidationErrors) {
    return (control: AbstractControl): { [key: string]: any } => {
      if (!control.value) {
        return null;
      }
      const valid = regex.test(control.value);
      console.log(valid)
      return valid ? null : error;
    };
  }

  calculatePricesItem() {

    let price=0;
    let amount =0;
    let totalPric =0;
    if (this.form.get('amount').valid && this.form.get('amount').value)
      amount = this.form.get('amount').value;
    if (this.form.get('price').valid && this.form.get('price').value)
      price = this.form.get('price').value;
    totalPric = (price * amount)*1 ;

    let pc = totalPric.toFixed(2);

    if (this.proformItems[0].totalPrice != pc) {
      this.proformItems[0].totalPrice = pc;
    }

  };

  download(urll): void {
    this.proformItemService.download(urll).subscribe(blob => {
      const a = document.createElement('a')
      const objectUrl = URL.createObjectURL(blob)
      a.href = objectUrl
      a.download = 'file';
      a.click();
      URL.revokeObjectURL(objectUrl);
    });
  }


}
