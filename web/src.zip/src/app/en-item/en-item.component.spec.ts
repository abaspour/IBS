import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {EnItemComponent} from './en-item.component';

describe('EnItemComponent', () => {
  let component: EnItemComponent;
  let fixture: ComponentFixture<EnItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
