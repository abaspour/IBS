import {inject, TestBed} from '@angular/core/testing';

import {EnItemGuard} from './en-item.guard';

describe('EnItemGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EnItemGuard]
    });
  });

  it('should ...', inject([EnItemGuard], (guard: EnItemGuard) => {
    expect(guard).toBeTruthy();
  }));
});
