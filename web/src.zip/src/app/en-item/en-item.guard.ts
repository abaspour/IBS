import {Injectable} from '@angular/core';
import {CanDeactivate} from '@angular/router';
import {Observable} from 'rxjs';
import {EnItemComponent} from "./en-item.component";

@Injectable({
  providedIn: 'root'
})
export class EnItemGuard implements CanDeactivate<EnItemComponent> {
  canDeactivate(component: EnItemComponent): Observable<boolean> | Promise<boolean> | boolean {
    if (component.form.dirty) {
      const countryName = component.form.get('inquiryNumber').value || '? ';
      return confirm(`Loose change(s) on screen for Inquiry ${countryName}?`);
    }
    return true;
  }
}
