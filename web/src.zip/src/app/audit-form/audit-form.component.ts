import {Component, OnDestroy, OnInit} from '@angular/core';
import {AbstractControl, FormControl, FormGroup, ValidationErrors, Validators} from '@angular/forms';
import {RegisterService} from '../shared/services/register.service';
import {Register} from '../shared/models/register';
import {TotalResponse} from '../shared/models/TotalResponse';
import {CountryService} from '../shared/services/country.service';
import {ActivatedRoute, Data, Router} from '@angular/router';
import {ToastrService} from 'ngx-toastr';
import {Subscription} from "rxjs";


export const EnglishAlphabetRegex = '^[a-zA-Z]\\S*$';
export const webSiteRegx = '^(https?:\\/\\/)?(www\\.)?([a-zA-Z0-9]+(-?[a-zA-Z0-9])*\\.)+[\\w]{2,}(\\/\\S*)?$';
export const telRegex = '^[+(]{1}\\d{1,4}[\\s)]{0,1}\\d{1,3}\\s{0,1}\\d{3,15}$';

@Component({
  selector: 'app-audit-form',
  templateUrl: './audit-form.component.html',
  styleUrls: ['./audit-form.component.scss']
})
export class AuditFormComponent implements OnInit, OnDestroy {

  fileData: File = null;
  previewUrl: any = null;
  regCountry: string = null;
  regNo: string = null;
  email:string = null;

  fields = [ /*"id","createdDate","createdBy", "lastModifiedDate","lastModifiedBy","version","registerNo",
  "registerDate","registerCountry","registerPlace",*/
    'fullName', 'fullAddress', 'telNo', 'faxNo', 'website', 'mainEmail',
    'officeFullAddress', 'officeTelNo', 'officeFaxNo', 'officeWebsite', 'officeMainEmail', 'companyType', /*"companyActivity",*/
    'iranAgency', 'agencyType', 'agencyFullName', 'agencyRegisterNo', 'agencyRegisterDate', 'agencyRegisterCountry',
    'agencyRegisterPlace', 'agencyFullAddress', 'agencyTelNo', 'agencyCelNo', 'agencyFaxNo', 'agencyWebsite', 'agencyMainEmail',
    'agencyRepresentValidDate', 'contactPersonName', 'contactPersonPosition', 'contactPersonTel', 'contactPersonEmail',
    'productsDetail'/*, 'oldFileName', 'newFileName'*/];
  agencyFields = [/*'iranAgency', 'agencyType', */'agencyFullName', 'agencyRegisterNo', 'agencyRegisterDate', 'agencyRegisterCountry',
    'agencyRegisterPlace', 'agencyFullAddress', 'agencyTelNo', 'agencyCelNo', 'agencyFaxNo', 'agencyWebsite', 'agencyMainEmail',
    'agencyRepresentValidDate'];
  hasAagencyFields = false;
  companyActivities = ['supplier', 'dealer', 'distributor', 'stockiest', 'representative', 'engineering', 'branch'];
  done = false;
  countries: [];

  register: Register;

  form: FormGroup = null;
  private formSubmitAttempt: boolean;

  constructor(private registerService: RegisterService,
              private countryService: CountryService,
              private router: Router,
              private activeRouter: ActivatedRoute,
              private toastr: ToastrService) {
  }

  ngOnInit() {
    this.form = new FormGroup({
      registerNo: new FormControl(null),
      registerDate: new FormControl(null, Validators.required),
      registerCountry: new FormControl(null),
      // countryCallingCode: new FormControl(null),
      registerPlace: new FormControl(null, Validators.required),
      fullName: new FormControl(null, Validators.required),
      fullAddress: new FormControl(null, Validators.required),
      telNo: new FormControl(null, [Validators.required, this.regexValidator(new RegExp(telRegex), {en: 'en'})]),
      faxNo: new FormControl(null, [Validators.required, this.regexValidator(new RegExp(telRegex), {en: 'en'})]),
      website: new FormControl(null, [Validators.required, this.regexValidator(new RegExp(webSiteRegx), {en: 'en'})]),
      mainEmail: new FormControl(null, [Validators.required, Validators.email]),
      officeFullAddress: new FormControl(null),
      officeTelNo: new FormControl(null, [this.regexValidator(new RegExp(telRegex), {en: 'en'})]),
      officeFaxNo: new FormControl(null, [this.regexValidator(new RegExp(telRegex), {en: 'en'})]),
      officeWebsite: new FormControl(null, [this.regexValidator(new RegExp(webSiteRegx), {en: 'en'})]),
      officeMainEmail: new FormControl(null, Validators.email),
      companyType: new FormControl(null, Validators.required),
      supplier: new FormControl(null),
      dealer: new FormControl(null),
      distributor: new FormControl(null),
      stockiest: new FormControl(null),
      representative: new FormControl(null),
      engineering: new FormControl(null),
      branch: new FormControl(null),
      iranAgency: new FormControl(null),
      agencyType: new FormControl(null),
      agencyFullName: new FormControl(null, [this.agencyValidator({en: 'en'})]),
      agencyRegisterNo: new FormControl(null, [this.agencyValidator({en: 'en'})]),
      agencyRegisterDate: new FormControl(null, [this.agencyValidator({en: 'en'})]),
      agencyRegisterCountry: new FormControl(null, [this.agencyValidator({en: 'en'})]),
      agencyRegisterPlace: new FormControl(null, [this.agencyValidator({en: 'en'})]),
      agencyFullAddress: new FormControl(null, [this.agencyValidator({en: 'en'})]),
      agencyTelNo: new FormControl(null, [this.agencyValidator({en: 'en'}), this.regexValidator(new RegExp(telRegex), {en: 'en'})]),
      agencyCelNo: new FormControl(null, [this.agencyValidator({en: 'en'})]),
      agencyFaxNo: new FormControl(null, [this.agencyValidator({en: 'en'}), this.regexValidator(new RegExp(telRegex), {en: 'en'})]),
      agencyWebsite: new FormControl(null, [this.agencyValidator({en: 'en'}), this.regexValidator(new RegExp(webSiteRegx), {en: 'en'})]),
      agencyMainEmail: new FormControl(null, [Validators.email, this.agencyValidator({en: 'en'})]),
      agencyRepresentValidDate: new FormControl(null, [this.agencyValidator({en: 'en'})]),
      contactPersonName: new FormControl(null, Validators.required),
      contactPersonPosition: new FormControl(null, Validators.required),
      contactPersonTel: new FormControl(null, [Validators.required, this.regexValidator(new RegExp(telRegex), {en: 'en'})]),
      contactPersonEmail: new FormControl(null, [Validators.required, Validators.email]),
      productsDetail: new FormControl(null, Validators.required),
    });

    this.countryService.getCountry(this).subscribe((data: TotalResponse) => {
      this.countries = data.response.data;
    });

    this.sub=this.activeRouter.params.subscribe((data: Data) => {
      this.regNo = data.regNo;
      this.regCountry = data.regCountry;
      if (this.regNo && this.regCountry) {
        this.form.patchValue({registerCountry: this.regCountry});
        this.form.patchValue({registerNo: this.regNo});
        const criteria= ` 0 , 0 , 0 , ${this.regNo} `;
        this.registerService.getRegister(criteria,this).subscribe((x: TotalResponse) => {
          if (x.response.totalRows == 1) {
            let registers : [ { registerNo: string, registerCountry: string, contactPersonEmail: string} ];
            registers=x.response.data;
            let r='';
            let c='';
            let email='';
            registers.forEach(_ => {
              r=_.registerNo;
              c=_.registerCountry;
              email=_.contactPersonEmail;
            });
            this.regNo = r;
            this.regCountry = c;
            this.email = email;

            this.form.patchValue({registerCountry: this.regCountry});
            this.form.patchValue({registerNo: this.regNo});
            this.form.patchValue({contactPersonEmail: this.email});
            this.toastr.info(' please fill out the form.', 'info', {timeOut: 30000, positionClass: 'toast-top-left'});
            this.allEnable();
            // this.done = true;
            // this.allDisable();
          } else if (x.response.totalRows > 1) {
            this.toastr.info(
              `  already registerd in NICICO system. We will contact you by Email.`,
              'info', {timeOut: 10000});
            this.done = true;
            this.allDisable();
            this.router.navigate([`/`]);
          } else {
            this.toastr.warning(" iD IS NOT CORRECT.",'error',{timeOut: 30000});
            this.router.navigate([`/help-audit`]);
          }

        });
      } else {
        this.allDisable();
      }
    });

  }
  private sub: Subscription;
  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }

  error(err) {
    console.log('err function', err);
    return false;
  }

  regexValidator(regex: RegExp, error: ValidationErrors) {
    return (control: AbstractControl): { [key: string]: any } => {
      if (!control.value) {
        return null;
      }
      const valid = regex.test(control.value);
      return valid ? null : error;
    };
  }

  agencyValidator(error: ValidationErrors) {
    return (control: AbstractControl): { [key: string]: any } => {
      if (control.value) {
        this.hasAagencyFields = true;
      } else if (!control.value && this.hasAagencyFields) {
        this.chkHasAagencyFields();
      }
      return null;
    };
  }

  chkHasAagencyFields() {
    this.hasAagencyFields = false;
    if (!this.form) {
      return;
    }
    this.agencyFields.forEach(_ => {
      if (this.form.get(_).value) {
        this.hasAagencyFields = true;
      }
    });
  }

  allHasAagencyFieldsValue() {
    if (!this.hasAagencyFields) {
      return true;
    }
    let out = true;
    this.agencyFields.forEach(_ => {
      if (!this.form.get(_).value) {
        out = false;
      }
    });
    return out;
  }

  onChanges() {
    // this.form.get('address.state').valueChanges.pipe(
    //   debounceTime(400),
    //   distinctUntilChanged())
    //   .subscribe(x => this.countries.push({id: this.id++, name: x}));
  }

  findCountry(id) {
    return id;
    // return this.countries.find((x) => {
    //   console.log('x.id=', x.id, id);
    //   return x.id == id;
    // }).countryNameEn;
  }

  isFieldValid(field: string) {
    if (this.done) {
      return false;
    }
    // console.log('this.hasAagencyFields' , this.hasAagencyFields,field,this.agencyFields.includes(field), this.form.get(field).value, !this.form.get(field).value)
    if (this.hasAagencyFields && this.agencyFields.includes(field) && (!this.form.get(field).value)) {
      return ((this.form.get(field).untouched && this.formSubmitAttempt) || this.form.get(field).touched);
    }
    return (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSubmitAttempt && !this.form.get(field).valid);
  }

  displayFieldCss(field: string) {
    if (this.done) {
      return {
        'has-error': false,
        'has-feedback': true
      };
    }
    let b = this.isFieldValid(field);
    return {
      'has-error': b,
      'has-feedback': b
    };
  }

  // validateAllFormFields(formGroup: FormGroup) {         //{1}
  //   Object.keys(formGroup.controls).forEach(field => {  //{2}
  //     const control = formGroup.get(field);             //{3}
  //     if (control instanceof FormControl) {             //{4}
  //       control.markAsTouched({ onlySelf: true });
  //     } else if (control instanceof FormGroup) {        //{5}
  //       this.validateAllFormFields(control);            //{6}
  //     }
  //   });
  // }
  onSubmit() {
    this.formSubmitAttempt = true;
    this.chkHasAagencyFields();
    console.log(this.allHasAagencyFieldsValue());
    if (!this.allHasAagencyFieldsValue()) {
      this.toastr.error('some agancy fields for your company must be enterd. if dont want please clear  all agancy fields',
        'error', {timeOut: 5000});
      return;
    }
    console.log(this.form);
    if (this.form.valid) {
      console.log('form submitted');
      console.log(this.form.getRawValue());
      this.register = this.form.getRawValue();
      this.register.companyActivity = '';
      this.companyActivities.forEach(_ => {
        if (this.form.get(_).value) {
          this.register.companyActivity += ',' + _;
        }
      });
      if (this.register.companyActivity.length === 0) {
        this.toastr.error('field  activity type for your company must be enterd', 'error', {timeOut: 5000});
        return;
      }
      this.register.companyActivity = this.register.companyActivity.substring(1);
      console.log(this.register);
      const formData = new FormData();
      formData.append('data', JSON.stringify(this.register));
      formData.append('file', this.fileData);

      this.registerService.addRegister(formData,this).subscribe(data => {
          console.log(data);
          this.toastr.success(' You have been successfully registered in NICICO. We will contact you by Email.', 'success', {timeOut: 10000});
          setTimeout(() => {
            this.router.navigate(['/']);
          }, 20000);
          this.formSubmitAttempt = false;
          this.done = true;
          this.allDisable();
        },
        error => {
          console.log('error', JSON.stringify(error.error));
        }
      );
    } else {
      this.toastr.error('Please fix error(s).', 'error', {timeOut: 10000});
      // console.log('companyActivity', this.register.companyActivity);
      // alert('same error/s on page');
    }
  }

  reset() {
    this.form.reset();
    this.formSubmitAttempt = false;
    this.form.patchValue({registerCountry: this.regCountry});
    this.form.patchValue({registerNo: this.regNo});
    this.toastr.info(' please fill out the form.', 'info', {timeOut: 30000, positionClass: 'toast-top-left'});
    this.allEnable();

  }

  allDisable() {
    this.fields.forEach(_ => this.form.get(_).disable());
  }

  allEnable() {
    this.fields.forEach(_ => this.form.get(_).enable());
  }

  fileProgress(fileInput: any) {
    this.fileData = <File>fileInput.target.files[0];
    this.preview();
  }

  preview() {
    // Show preview
    const mimeType = this.fileData.type;
    if (mimeType.match(/image\/*/) == null) {
      return;
    }

    let reader = new FileReader();
    reader.readAsDataURL(this.fileData);
    reader.onload = (_event) => {
      this.previewUrl = reader.result;
    };

  }


//   onSubmit() {
//     if (this.form.valid) {
//       console.log('form submitted');
//     } else {
//       this.validateAllFormFields(this.form);
//     }
//   }
}

// import { Component, OnInit } from '@angular/core';
// import {FormControl, FormGroup, Validators} from '@angular/forms';
//
// @Component({
//   selector: 'app-first',
//   templateUrl: './first.component.html',
//   styleUrls: ['./first.component.scss']
// })
//
//   genders = ['male', 'female'];
//   inputForm: FormGroup;
//
//   constructor() { }
//
//   ngOnInit() {
//     this.inputForm = new FormGroup({
//       'username': new FormControl( null, Validators.required),
//       'email': new FormControl(null, [Validators.required, Validators.email]),
//       gender: new FormControl("male")
//     });
//   }
//   onSubmit() {
//      console.log(this.inputForm);
//   }
//
// }
//  {
//       this.registerService.getRegister(this.fc).subscribe((data: TotalResponse) => {
//         this.register = data.response.data[0];
//         if (this.register != null) {
//           console.log(this.register);
//           // this.form.setValue(this.register,);
//           this.form.setValue({
//             registerNo: this.register.registerNo,
//             registerDate: this.register.registerDate,
//             registerCountry: this.register.registerCountry,
//             registerPlace: this.register.registerPlace,
//             fullName: this.register.fullName,
//             fullAddress: this.register.fullAddress,
//             telNo: this.register.telNo,
//             faxNo: this.register.faxNo,
//             website: this.register.website,
//             mainEmail: this.register.mainEmail,
//             officeFullAddress: this.register.officeFullAddress,
//             officeTelNo: this.register.officeTelNo,
//             officeFaxNo: this.register.officeFaxNo,
//             officeWebsite: this.register.officeWebsite,
//             officeMainEmail: this.register.officeMainEmail,
//             companyType: this.register.companyType,
//             supplier: this.register.companyActivity.includes('supplier'),
//             dealer: this.register.companyActivity.includes('dealer'),
//             distributor: this.register.companyActivity.includes('distributor'),
//             stockiest: this.register.companyActivity.includes('stockiest'),
//             representative: this.register.companyActivity.includes('representative'),
//             engineering: this.register.companyActivity.includes('engineering'),
//             branch: this.register.companyActivity.includes('branch'),
//             iranAgency: this.register.iranAgency,
//             agencyType: this.register.agencyType,
//             agencyFullName: this.register.agencyFullName,
//             agencyRegisterNo: this.register.agencyRegisterNo,
//             agencyRegisterDate: this.register.agencyRegisterDate,
//             agencyRegisterCountry: this.register.agencyRegisterCountry,
//             agencyRegisterPlace: this.register.agencyRegisterPlace,
//             agencyFullAddress: this.register.agencyFullAddress,
//             agencyTelNo: this.register.agencyTelNo,
//             agencyCelNo: this.register.agencyCelNo,
//             agencyFaxNo: this.register.agencyFaxNo,
//             agencyWebsite: this.register.agencyWebsite,
//             agencyMainEmail: this.register.agencyMainEmail,
//             agencyRepresentValidDate: this.register.agencyRepresentValidDate,
//             contactPersonName: this.register.contactPersonName,
//             contactPersonPosition: this.register.contactPersonPosition,
//             contactPersonTel: this.register.contactPersonTel,
//             contactPersonEmail: this.register.contactPersonEmail,
//             productsDetail: this.register.productsDetail,
//             oldFileName: this.register.oldFileName,
//             newFileName: this.register.newFileName,
//           });
//           console.log('subscribe', this.form.getRawValue());
//
//         }
//
//       });
//       this.onChanges();
//     }
