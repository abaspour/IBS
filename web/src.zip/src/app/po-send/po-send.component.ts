import {Component, OnInit} from '@angular/core';
import {AbstractControl, FormControl, FormGroup, ValidationErrors, Validators} from "@angular/forms";
import {ActivatedRoute, Data, Router} from "@angular/router";
import {ToastrService} from "ngx-toastr";
import {TotalResponse} from "../shared/models/TotalResponse";
import {Subscription} from "rxjs";
import {Inquiry} from "../shared/models/inquiry";
import {InquiryService} from "../shared/services/inquiry.service";
import {InquiryPortage} from "../shared/models/InquiryPortage";
import {InquiryPortageService} from "../shared/services/inquiry-portage.service";
import {Currency} from "../shared/models/Currency";
import {CurrencyService} from "../shared/services/currency.service";

export const num2prcision = "^\\d*\\.?\\d{0,2}$";
export const num = "^\\d*$";
export const EnglishAlphabetRegex = '^[a-zA-Z]\\S*$';
export const telRegex = '^[+(]{1}\\d{1,4}[\\s)]{0,1}\\d{1,3}\\s{0,1}\\d{3,15}$';

@Component({
  selector: 'app-po-send',
  templateUrl: './po-send.component.html',
  styleUrls: ['./po-send.component.scss']
})
export class PoSendComponent implements OnInit {
  inquiries: [Inquiry];
  inquiryPortages: [InquiryPortage];
  currencies: [Currency];
  fileData: File = null;
  previewUrl: any = null;
  form: FormGroup = null;
  startRow = 1;
  totalRows = 0;
  page = 5;
  endRow = 5;
  errorMessage = '';
  inquiryNumber: string;
  inquiryName: string;
  inquiryDate: string;
  endReplyDate: string;
  filter = false;
  formSubmitAttempt = false;
  commitInq = false;
  commitPro = false;

  criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"supplierId", "operator":"notNull" } ] } `;

  constructor(private router: Router,
              private toastr: ToastrService,
              private activeRouter: ActivatedRoute,
              private currencyService: CurrencyService,
              private inquiryPortageService: InquiryPortageService,
              private inquiryService: InquiryService) {
  }

  ngOnInit() {
    this.form = new FormGroup({
      inquiryNumber: new FormControl(null),
      verify_: new FormControl('', Validators.required),
      file__: new FormControl('', Validators.required),
      supplierDescription: new FormControl('', Validators.required),
      price: new FormControl('', [Validators.required, Validators.min(0), Validators.max(10000001), this.regexValidator(new RegExp(num2prcision), {en: 'en'})]),
      currencyId: new FormControl('', Validators.required)
    });
    this.sub = this.activeRouter.params.subscribe((data: Data) => {
      this.inquiryNumber = data.inquiryNumber;
      if (this.inquiryNumber) {
        this.criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"inquiryNumber", "operator":"equals", "value": "${this.inquiryNumber}"  } ] } `;
        this.subscribe(this.criteria + `&_startRow=${this.startRow - 1}&_endRow=${this.endRow}&_sortBy=inquiryNumber`);
      }
    });
    let criteriaa = `{ "operator":"and", "criteria" : [  { "fieldName":"isActive", "operator":"equals", "value": "y"  } ] }&_startRow=0&_endRow=2000&_sortBy=nameEn`;
    this.currencyService.getCurrency(criteriaa, this).subscribe(
      (data: TotalResponse) => this.currencies = data.response.data
    );

  }

  private sub: Subscription;

  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }

  regexValidator(regex: RegExp, error: ValidationErrors) {
    return (control: AbstractControl): { [key: string]: any } => {
      if (!control.value) {
        return null;
      }
      const valid = regex.test(control.value);
      console.log(valid)
      return valid ? null : error;
    };
  }

  subscribe(criteria) {
    this.inquiryService.getInquiry(criteria, this).subscribe({
      next: (data: TotalResponse) => {
        this.inquiries = data.response.data;
        this.inquiries.forEach(_ => {
          this.form.patchValue(
            {
              inquiryNumber: _.inquiryNumber,
              verify_: _.verify,
            });
        });
        this.endRow = data.response.endRow;
        this.startRow = data.response.startRow + 1;
        this.totalRows = data.response.totalRows;
      }
    });
    this.inquiryPortageService.getInquiryPortage(criteria, this).subscribe({
      next: (data: TotalResponse) => {
        this.inquiryPortages = data.response.data;
        this.inquiryPortages.forEach(_ => {
          this.form.patchValue(
            {
              price: _.price,
              currencyId: _.currencyId,
              supplierDescription: _.supplierDescription,
            });
        });
        this.endRow = data.response.endRow;
        this.startRow = data.response.startRow + 1;
        this.totalRows = data.response.totalRows;
      }
    })
    // error : err => this.errorMessage = err
  }

  onClickBack(inq) {
    this.router.navigate([`inquiry`]);
  }

  isFieldValid(field: string) {
    if (this.form.get(field).valid) {
      return null;
    }
    return (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSubmitAttempt);
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  fileProgress(fileInput: any) {
    this.fileData = <File>fileInput.target.files[0];
    this.preview();
  }

  preview() {
    // Show preview
    const mimeType = this.fileData.type;
    if (mimeType.match(/image\/*/) == null) {
      return;
    }

    let reader = new FileReader();
    reader.readAsDataURL(this.fileData);
    reader.onload = (_event) => {
      this.previewUrl = reader.result;
    };
  }

  onClickNxt() {
    if (!this.form.get('verify_').value) {
      this.toastr.error('Please click "کلیه اسناد را به دقت مشاهده و بررسی نموده ام و با اطلاع از کلیه شرایط پیشنهاد قیمت خود را ارسال می نماییم"',
        'error', {timeOut: 5000});
      this.formSubmitAttempt = false;
      return;
    }
    this.formSubmitAttempt = true;
    if (this.form.valid && this.form.dirty) {
      let _ = this.form.getRawValue();
//
      this.inquiries[0].inquiryNumber = _.inquiryNumber;
      this.inquiries[0].verify = _.verify_;
      this.inquiries[0].verifyStatus = "r";
      this.inquiries[0].changeStatus = "2";
//
      const formData = new FormData();
      formData.append('data', JSON.stringify(this.inquiries[0]));
      formData.append('file', this.fileData);

      this.inquiryService.updateInquiry(formData,
        this.inquiries[0].id, this).subscribe(data => {
          this.commitInq = true;
          if (this.commitPro) {
            this.toastr.success('  پاسخ استعلام با موفقیت ارسال شد..', 'success', {timeOut: 10000});
            setTimeout(() => {
              this.form.reset();
              this.router.navigate([`replied`]);
            }, 200);
            this.formSubmitAttempt = false;
          }
        },
        error => {
          this.toastr.error(' Error .' + JSON.stringify(error.error), 'Error', {timeOut: 10000});
          setTimeout(() => {
            // this.router.navigate(['/']);
          }, 20000);
        }
      );
      this.inquiryPortages[0].price = _.price;
      this.inquiryPortages[0].currencyId = _.currencyId;
      this.inquiryPortages[0].supplierDescription = _.supplierDescription;
//
      const formData1 = new FormData();
      formData1.append('data', JSON.stringify(this.inquiryPortages[0]));

      this.inquiryPortageService.updateInquiryPortage(formData1,
        this.inquiryPortages[0].id, this).subscribe(data => {
          this.commitPro = true;
          if (this.commitInq) {
            this.toastr.success(' پاسخ استعلام با موفقیت ارسال شد.', 'success', {timeOut: 10000});
            setTimeout(() => {
              this.form.reset();
              this.router.navigate([`replied`]);
            }, 200);
            this.formSubmitAttempt = false;
          }
        },
        error => {
          this.toastr.error(' Error .' + JSON.stringify(error.error), 'Error', {timeOut: 10000});
          setTimeout(() => {
            // this.router.navigate(['/']);
          }, 20000);
        }
      );

    } else if (this.form.valid) {
      this.router.navigate([`replied`]);
    } else {
      this.toastr.error('لطفا نسبت به تکمیل و اصلاح خطا یا خطاها اقدام نمایید.', 'error', {timeOut: 10000});
    }

  }
}
