import {Injectable} from '@angular/core';
import {CanDeactivate} from '@angular/router';
import {Observable} from 'rxjs';
import {PoSendComponent} from "./po-send.component";


@Injectable({
  providedIn: 'root'
})
export class PoSendGuard implements CanDeactivate<PoSendComponent> {
  canDeactivate(component: PoSendComponent): Observable<boolean> | Promise<boolean> | boolean {
    if (component.form.dirty) {
      const countryName = component.form.get('inquiryNumber').value || ' ?  ';
      return confirm(`Loose change(s) on screen for Inquiry ${countryName}?`);
    }
    return true;
  }
}

