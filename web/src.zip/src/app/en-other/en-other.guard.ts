import {Injectable} from '@angular/core';
import {CanDeactivate} from '@angular/router';
import {Observable} from 'rxjs';
import {EnOtherComponent} from "./en-other.component";


@Injectable({
  providedIn: 'root'
})
export class EnOtherGuard implements CanDeactivate<EnOtherComponent> {
  canDeactivate(component: EnOtherComponent): Observable<boolean> | Promise<boolean> | boolean {
    if (component.form.dirty) {
      const countryName = component.proform[0].inquiryNumber || ' ? ';
      return confirm(`Loose change(s) on screen for Inquiry ${countryName}?`);
    }
    return true;
  }
}

