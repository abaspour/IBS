import {Component, ElementRef, OnInit, ViewChildren} from '@angular/core';
import {AbstractControl, FormControl, FormControlName, FormGroup, ValidationErrors, Validators} from "@angular/forms";
import {ActivatedRoute, Data, Router} from "@angular/router";
import {ToastrService} from "ngx-toastr";
import {TotalResponse} from "../shared/models/TotalResponse";
import {fromEvent, merge, Observable, Subscription} from "rxjs";
import {debounceTime} from "rxjs/operators";
import {Proform} from "../shared/models/Proform";
import {ProformService} from "../shared/services/proform.service";
import {CurrencyService} from "../shared/services/currency.service";
import {Currency} from "../shared/models/Currency";
import {Custom} from "../shared/models/Custom";
import {PaymentMethod} from "../shared/models/PaymentMethod";
import {PurchaseType} from "../shared/models/PurchaseType";
import {TransmitInstrument} from "../shared/models/TransmitInstrument";
import {PurchaseTypeService} from "../shared/services/purchase-type.service";
import {CustomService} from "../shared/services/custom.service";
import {PaymentMethodService} from "../shared/services/payment-method.service";
import {TransmitInstrumentService} from "../shared/services/transmit-instrument.service";
import {CountryService} from "../shared/services/country.service";
import {Country} from "../country";

export const num2prcision = "^\\d*\\.?\\d{0,2}$";
export const num = "^\\d*$";
export const EnglishAlphabetRegex = '^[a-zA-Z]\\S*$';
export const telRegex = '^[+(]{1}\\d{1,4}[\\s)]{0,1}\\d{1,3}\\s{0,1}\\d{3,15}$';


@Component({
  selector: 'app-en-other',
  templateUrl: './en-other.component.html',
  styleUrls: ['./en-other.component.scss']
})
export class EnOtherComponent implements OnInit {
  @ViewChildren(FormControlName, {read: ElementRef}) formInputElements: ElementRef[];

  proform: [Proform];
  currencies: [Currency];
  purchaseTypes: [PurchaseType];
  countryLoadings: [Country];
  transmitInstruments: [TransmitInstrument];
  paymentMethods: [PaymentMethod];
  customs: [Custom];
  fileData: File = null;
  previewUrl: any = null;
  form: FormGroup = null;
  pageTitle = 'استعلامهای جدید یا مشاهده شده';
  startRow = 1;
  totalRows = 0;
  page = 5;
  endRow = 5;
  errorMessage = '';
  inquiryNumber: string;
  inquiryName: string;
  inquiryDate: string;
  endReplyDate: string;
  filter = false;
  formSubmitAttempt = false;
  showTransmit = true;
  showCustom = true;
  showCountry = true;

  criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"supplierId", "operator":"notNull" } ] } `;

  constructor(private router: Router,
              private toastr: ToastrService,
              private activeRouter: ActivatedRoute,
              private currencyService: CurrencyService,
              private countryService: CountryService,
              private purchaseTypeService: PurchaseTypeService,
              private transmitInstrumentService: TransmitInstrumentService,
              private paymentMethodService: PaymentMethodService,
              private customService: CustomService,
              private proformService: ProformService) {
  }

  ngOnInit() {
    this.form = new FormGroup({
      rappingcost: new FormControl('', [Validators.required, Validators.min(0), Validators.max(1000001), this.regexValidator(new RegExp(num2prcision), {en: 'en'})]),
      usancecost: new FormControl('', [Validators.required, Validators.min(0), Validators.max(1000001), this.regexValidator(new RegExp(num2prcision), {en: 'en'})]),
      fca: new FormControl('', [Validators.required, Validators.min(0), Validators.max(1000001), this.regexValidator(new RegExp(num2prcision), {en: 'en'})]),
      othercost: new FormControl('', [Validators.required, Validators.min(0), Validators.max(1000001), this.regexValidator(new RegExp(num2prcision), {en: 'en'})]),
      discountproform: new FormControl('', [Validators.required, Validators.min(0), Validators.max(1000001), this.regexValidator(new RegExp(num2prcision), {en: 'en'})]),
      pureweight: new FormControl('', [Validators.required, Validators.min(0), Validators.max(1000001), this.regexValidator(new RegExp(num), {en: 'en'})]),
      impureweight: new FormControl('', [Validators.required, Validators.min(0), Validators.max(1000001), this.regexValidator(new RegExp(num), {en: 'en'})]),
      deliverttime: new FormControl('', [Validators.required, Validators.min(0), Validators.max(1000001), this.regexValidator(new RegExp(num), {en: 'en'})]),
      purchaseTypeId: new FormControl('', [Validators.required, Validators.min(0), Validators.max(1000001), this.regexValidator(new RegExp(num), {en: 'en'})]),
      countryLoadingId: new FormControl('', [Validators.required, Validators.min(0), Validators.max(1000001), this.regexValidator(new RegExp(num), {en: 'en'})]),
      transmitInstrumentId: new FormControl('', [Validators.required, Validators.min(0), Validators.max(1000001), this.regexValidator(new RegExp(num), {en: 'en'})]),
      paymentMethodId: new FormControl('', [Validators.required, Validators.min(0), Validators.max(1000001), this.regexValidator(new RegExp(num), {en: 'en'})]),
      currencyId: new FormControl('', [Validators.required, Validators.min(0), Validators.max(10000000001), this.regexValidator(new RegExp(num), {en: 'en'})]),
      customId: new FormControl('', [Validators.required, Validators.min(0), Validators.max(1000001), this.regexValidator(new RegExp(num), {en: 'en'})]),
    });
    // this.form.get('priceBeforeDiscount').disable()
    // this.form.get('gheymateKol').disable()
    this.sub=this.activeRouter.params.subscribe((data: Data) => {
      this.inquiryNumber = data.inquiryNumber;
      if (this.inquiryNumber) {
        this.criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"id", "operator":"equals", "value": "${this.inquiryNumber}"  } ] } `;
        this.subscribe(this.criteria + `&_startRow=${this.startRow - 1}&_endRow=${this.endRow}&_sortBy=inquiryNumber`);
      }
    });
    let criteriaa = `{ "operator":"and", "criteria" : [  { "fieldName":"isActive", "operator":"equals", "value": "y"  } ] }&_startRow=0&_endRow=2000&_sortBy=nameEn`;
    this.currencyService.getCurrency(criteriaa,this).subscribe(
      (data: TotalResponse) => this.currencies = data.response.data
    );
    this.purchaseTypeService.getPurchaseType(criteriaa,this).subscribe(
      (data: TotalResponse) => this.purchaseTypes = data.response.data
    );
    this.transmitInstrumentService.getTransmitInstrument(criteriaa,this).subscribe(
      (data: TotalResponse) => this.transmitInstruments = data.response.data
    );
    this.paymentMethodService.getPaymentMethod(criteriaa,this).subscribe(
      (data: TotalResponse) => this.paymentMethods = data.response.data
    );
    this.customService.getCustom(criteriaa,this).subscribe(
      (data: TotalResponse) => this.customs = data.response.data
    );
    this.countryService.getCountry(this).subscribe(
      (data: TotalResponse) => this.countryLoadings = data.response.data
    );
  }
  private sub: Subscription;
  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }
  ngAfterViewInit(): void {
    // Watch for the blur event from any input element on the form.
    // This is required because the valueChanges does not provide notification on blur
    const controlBlurs: Observable<any>[] = this.formInputElements
      .map((formControl: ElementRef) => fromEvent(formControl.nativeElement, 'blur'));

    // Merge the blur event observable with the valueChanges observable
    // so we only need to subscribe once.
    merge(this.form.valueChanges, ...controlBlurs).pipe(
      debounceTime(800)
    ).subscribe(value => {
      this.calculatePricesItem();
    });
  }

  subscribe(criteria) {
    this.proformService.getProform(criteria,this).subscribe({
      next: (data: TotalResponse) => {
        this.proform = data.response.data;
        this.proform.forEach(_ => {
          this.form.patchValue(
            {
              rappingcost: _.rappingcost,
              usancecost: _.usancecost,
              fca: _.fca,
              othercost: _.othercost,
              discountproform: _.discountproform,
              pureweight: _.pureweight,
              impureweight: _.impureweight,
              deliverttime: _.deliverttime,
              purchaseTypeId: _.purchaseTypeId,
              countryLoadingId: _.countryLoadingId,
              transmitInstrumentId: _.transmitInstrumentId,
              paymentMethodId: _.paymentMethodId,
              currencyId:_.currencyId,
              customId: _.customId
            });
        });
        this.endRow = data.response.endRow;
        this.startRow = data.response.startRow + 1;
        this.totalRows = data.response.totalRows;
        this.form.get('purchaseTypeId').valueChanges.subscribe(_ => {
          this.showHideFields();
        });
        this.showHideFields();
      }
      // error : err => this.errorMessage = err
    });

  }
  showHideFields() {
    if (this.form.get('purchaseTypeId').valid) {
      if (this.form.get('purchaseTypeId').value == 5 || this.form.get('purchaseTypeId').value == 6) {
        this.showTransmit = false;
        this.form.get("transmitInstrumentId").clearValidators();
        this.showCustom = false;
        this.form.get("customId").clearValidators();
        this.showCountry = true;
        this.form.get("countryLoadingId").setValidators([Validators.required]);
      } else if (this.form.get('purchaseTypeId').value == 11) {
        this.showTransmit = false;
        this.form.get("transmitInstrumentId").clearValidators();
        this.showCustom = false;
        this.form.get("customId").clearValidators();
        this.showCountry = false;
        this.form.get("countryLoadingId").clearValidators();
      } else {
        this.showTransmit = true;
        this.form.get("transmitInstrumentId").setValidators([Validators.required]);
        this.showCustom = true;
        this.form.get("customId").setValidators([Validators.required]);
        this.showCountry = true;
        this.form.get("countryLoadingId").setValidators([Validators.required]);
      }
    this.form.get("transmitInstrumentId").updateValueAndValidity();
    this.form.get("customId").updateValueAndValidity();
    this.form.get("countryLoadingId").updateValueAndValidity();
  }
  }

  onClickBack(inq) {
    this.router.navigate([`enItem-list/${inq}`]);
  }

  isFieldValid(field: string) {
    if (this.form.get(field).valid) {
      return null;
    }
    return (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSubmitAttempt);
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }
  fileCss() {
    let vali= false;
    if (!this.form.get('spareProductTime') || this.form.get('spareProductTime').value <'0'  || this.form.get('spareProductFileName').value || this.fileData!=null)
      vali=true;
    console.log('css=',vali)
    return {
      'has-error': !vali,
      'has-feedback': vali
    }
  }

  fileProgress(fileInput: any) {
    this.fileData = <File>fileInput.target.files[0];
    this.preview();
  }

  preview() {
    // Show preview
    const mimeType = this.fileData.type;
    if (mimeType.match(/image\/*/) == null) {
      return;
    }

    let reader = new FileReader();
    reader.readAsDataURL(this.fileData);
    reader.onload = (_event) => {
      this.previewUrl = reader.result;
    };
  }

  onClickNxt() {
    this.calculatePricesItem();
    this.formSubmitAttempt = true;
    if (this.form.valid && this.form.dirty) {
      let _ = this.form.getRawValue();
      this.proform[0].rappingcost= _.rappingcost;
      this.proform[0].usancecost= _.usancecost;
      this.proform[0].fca= _.fca;
      this.proform[0].othercost= _.othercost;
      this.proform[0].discountproform= _.discountproform;
      this.proform[0].pureweight= _.pureweight;
      this.proform[0].impureweight= _.impureweight;
      this.proform[0].deliverttime= _.deliverttime;
      this.proform[0].purchaseTypeId= _.purchaseTypeId;
      this.proform[0].countryLoadingId= _.countryLoadingId;
      this.proform[0].transmitInstrumentId= _.transmitInstrumentId;
      this.proform[0].paymentMethodId= _.paymentMethodId;
      this.proform[0].currencyId= _.currencyId;
      this.proform[0].customId= _.customId;
//

      const formData = new FormData();
      formData.append('data', JSON.stringify(this.proform[0]));
      if (this.fileData){
        formData.append('file', this.fileData);
      } else {
        formData.append('file', null);
      }

      this.proformService.updateProform(formData,
        this.proform[0].id,this).subscribe(data => {
          this.toastr.success(' Successfully Submitted.', 'success', {timeOut: 10000});
          setTimeout(() => {
            this.form.reset();
            this.router.navigate([`enSend/${this.proform[0].inquiryNumber}`]);
          }, 200);
          this.formSubmitAttempt = false;
        },
        error => {
          this.toastr.error(' Error .' + JSON.stringify(error.error), 'Error', {timeOut: 10000});
          setTimeout(() => {
            // this.router.navigate(['/']);
          }, 20000);
        }
      );
    } else if (this.form.valid) {
      this.router.navigate([`enSend/${this.proform[0].inquiryNumber}`]);
    }
    else {
      console.log(this.form);
      this.toastr.error('Please fix error(s).', 'error', {timeOut: 10000});
      // console.log('companyActivity', this.register.companyActivity);
      // alert('same error/s on page');
    }

  }

  regexValidator(regex: RegExp, error: ValidationErrors) {
    return (control: AbstractControl): { [key: string]: any } => {
      if (!control.value) {
        return null;
      }
      const valid = regex.test(control.value);
      console.log(valid)
      return valid ? null : error;
    };
  }
  calculatePricesItem() {
    let RP = 0;
    let UC = 0;
    let OC = 0;
    let fca = 0;
    let discount = 0;
    let sum1=0;
      sum1 = this.proform[0].totalsumitemscost;
    if (this.form.get('rappingcost').valid && this.form.get('rappingcost').value)
      RP = this.form.get('rappingcost').value;
    if (this.form.get('usancecost').valid && this.form.get('usancecost').value)
      UC = this.form.get('usancecost').value;
    if (this.form.get('othercost').valid && this.form.get('othercost').value)
      OC = this.form.get('othercost').value;
    if (this.form.get('fca').valid && this.form.get('fca').value)
      fca = this.form.get('fca').value;
    if (this.form.get('discountproform').valid && this.form.get('discountproform').value)
      discount = this.form.get('discountproform').value;

    let totlaPrices = 0;
    totlaPrices = (RP*1) + (sum1*1) + (UC*1) + (OC*1) + (fca*1) - (discount*1);
    this.proform[0].totalprice=totlaPrices.toFixed(2);
    };

  // download(urll): void {
  //   this.registerPriceService.download(urll).subscribe(response => {
  //     let blob: any = new Blob([response], {type: 'text/json; charset=utf-8'});
  //     const url = window.URL.createObjectURL(blob);
  //     window.open(url);
  //     // window.location.href = response.url;
  //     //fileSaver.saveAs(blob, 'employees.json');
  //   }), error => console.log('Error downloading the file'),
  //     () => console.info('File downloaded successfully');
  // }

  download(urll): void {
    this.proformService.download(urll).subscribe(blob => {
      const a = document.createElement('a')
      const objectUrl = URL.createObjectURL(blob)
      a.href = objectUrl
      a.download = 'file';
      a.click();
      URL.revokeObjectURL(objectUrl);
    });
  }


}
