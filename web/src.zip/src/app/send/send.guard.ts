import {Injectable} from '@angular/core';
import {CanDeactivate} from '@angular/router';
import {Observable} from 'rxjs';
import {SendComponent} from "./send.component";


@Injectable({
  providedIn: 'root'
})
export class SendGuard implements CanDeactivate<SendComponent> {
  canDeactivate(component: SendComponent): Observable<boolean> | Promise<boolean> | boolean {
    if (component.form.dirty) {
      const countryName = component.form.get('inquiryNumber').value || ' می گردد. مطمئن هستید؟ ';
      return confirm(`خروج از صفحه باعث عدم ذخیره تغییرات داده شده برای استعلام ${countryName}?`);
    }
    return true;
  }
}

