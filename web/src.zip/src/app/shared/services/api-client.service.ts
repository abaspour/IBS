import {Injectable} from '@angular/core';
import {EMPTY, Observable} from 'rxjs';
import {catchError, map} from 'rxjs/operators';
import {FormContainer} from '../models/ApiHelper';
import {HttpClient, HttpErrorResponse, HttpHeaders} from '@angular/common/http';
import {LocalstorageService} from "./localstorage.service";
import {MatSnackBar} from "@angular/material/snack-bar";
import {Router} from "@angular/router";

@Injectable({
  providedIn: 'root'
})
export class ApiClientService {

  constructor(private http: HttpClient,
              private router: Router,
              private matSnackBar: MatSnackBar) {
  }


  getHeaders(config?: ApiConfig) {
    let headers = new HttpHeaders();
    if (!config || !config.noAuth) {
      if (this.getCurrentAuthToken()) {
        headers = headers.set('Authorization', this.getCurrentAuthToken());
      }
    }
    return headers;
  }

  getCurrentAuthToken() {
    return LocalstorageService.getToken() ;
  }

  post<T>(api: string, data: any, component: FormContainer, config?: ApiConfig): Observable<T> {
    if (component) {
      component.isWorking = true;
    }
    return this.http.post<T>(api, data, {headers: this.getHeaders(config)})
      .pipe(
        map(res => this.processResponse(res, component)),
        catchError(err => this.processError(err, component)));
  }

  put<T>(api: string, data: any, component: FormContainer, config?: ApiConfig): Observable<T> {
    if (component) {
      component.isWorking = true;
    }
    return this.http.put<T>(api, data, {headers: this.getHeaders(config)})
      .pipe(
        map(res => this.processResponse(res, component)),
        catchError(err => this.processError(err, component)));
  }

  download(url: string, config?: ApiConfig): Observable<any> {
    return this.http.get(url, {
      responseType: 'blob',
      headers: this.getHeaders(config)
    })
  }

  getAno<T>(api: string, component: FormContainer, config?: ApiConfig): Observable<T> {
    if (component) {
      component.isWorking = true;
    }
    return this.http.get<T>(api)
      .pipe(
        map(res => this.processResponse(res, component)),
        catchError(err => this.processError(err, component)));
  }

  get<T>(api: string, component: FormContainer, config?: ApiConfig): Observable<T> {
    if (component) {
      component.isWorking = true;
    }
    return this.http.get<T>(api, {headers: this.getHeaders(config)})
      .pipe(
        map(res => this.processResponse(res, component)),
        catchError(err => this.processError(err, component)));
  }

  delete<T>(api: string, component: FormContainer, config?: ApiConfig): Observable<T> {
    if (component) {
      component.isWorking = true;
    }
    return this.http.delete<T>(api, {headers: this.getHeaders(config)})
      .pipe(
        map(res => this.processResponse(res, component)),
        catchError(err => this.processError(err, component)));
  }

  processResponse<T>(res: T, component: FormContainer) {
    if (component) {
      component.isWorking = false;
    }
    return res;
  }

  processError(err: HttpErrorResponse, component: FormContainer) {
    if (component) {
      component.isWorking = false;
    }
    if (component && component.handleError) {
      component.handleError(err);
      return EMPTY;
    } else {
       if (err.status==401) {
         this.matSnackBar.open('انقضای مدت کاری Session Expired. لطفا به سامانه وارد شوید Please Login ', '', {
           panelClass: 'error-snack',
           direction: "rtl",
           duration: 30000
         });
         this.router.navigate(['/']);
       }
       else {
        this.matSnackBar.open('بروز خطای '+err.status+' در سرور', '', {
          panelClass: 'error-snack',
          direction: "rtl",
          duration: 3000
        });
      }
      return EMPTY;
    }
  }
  login(credentials: any, component?: FormContainer): Observable<any> {
    if (component) {
      component.isWorking = true;
    }
    let header = new HttpHeaders({Authorization: 'Basic ' + btoa(credentials.username + ':' + credentials.password)});

    return this.http.post<any>(`http://localhost:8080/ibs/api/users/authenticate`, {
      'username': credentials.username,
      'password': credentials.password
    }, {headers: header})
      .pipe(map(user => {
          if (user['username']) {
            LocalstorageService.setBasicAuth( JSON.stringify(user));
            let authString = 'Basic ' + btoa(credentials.username + ':' + credentials.password);
            LocalstorageService.setFaToken(authString);
          } else {
            LocalstorageService.clearAll();
          }
          return user;
        }),
        catchError(err => this.processError(err, component)));
  }

  isUserLoggedIn(): boolean {
    return (LocalstorageService.getLang()==='fa');
  }

  enLogin(credentials: any, component?: FormContainer): Observable<any> {
    if (component) {
      component.isWorking = true;
    }
    let header = new HttpHeaders({Authorization: 'Basic ' + btoa(credentials.username + '@@:' + credentials.password)});

    return this.http.post<any>(`http://localhost:8080/ibs/api/users/authenticate`, {
      'username': credentials.username,
      'password': credentials.password
    }, {headers: header})
      .pipe(map(user => {
          if (user['username']) {
            LocalstorageService.setBasicAuth( JSON.stringify(user));
            let authString = 'Basic ' + btoa(credentials.username + '@@:' + credentials.password);
            LocalstorageService.setEnToken(authString);
          } else {
            LocalstorageService.clearAll();
          }
          return user;
        }),
        catchError(err => this.processError(err, component)));
  }

  isUserEnLoggedIn(): boolean {
    return (LocalstorageService.getLang()==='en');
  }

}

export interface ApiConfig {
  noAuth?: boolean;
  allowAnonymous: boolean;
}
