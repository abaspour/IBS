import {Injectable} from '@angular/core';
import {ApiClientService} from './api-client.service';

@Injectable({
  providedIn: 'root'
})
export class DeliveryTypeService {

  private static getDeliveryTypeUrl = `http://localhost:8080/ibs/api/deliveryType/`;

  constructor(private apiClient: ApiClientService) {
  }


  getDeliveryType(criteria,fc?) {
    return this.apiClient.get(DeliveryTypeService.getDeliveryTypeUrl + 'iso-search?criteria=' + criteria, fc);
  }
}
