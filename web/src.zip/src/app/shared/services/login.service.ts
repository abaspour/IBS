import {Injectable} from '@angular/core';
import {ApiClientService} from "./api-client.service";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private apiClient: ApiClientService) {
  }

  login(credentials, fc): Observable<any> {
    return this.apiClient.login(credentials, fc);
  }

  isUserLoggedIn(): boolean {
    return this.apiClient.isUserLoggedIn()
  }
  enLogin(credentials, fc): Observable<any> {
    return this.apiClient.enLogin(credentials, fc);
  }

  isUserEnLoggedIn(): boolean {
    return this.apiClient.isUserEnLoggedIn()
  }
}
