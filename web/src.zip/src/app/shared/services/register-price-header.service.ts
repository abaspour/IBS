import {Injectable} from '@angular/core';
import {ApiClientService} from "./api-client.service";

@Injectable({
  providedIn: 'root'
})
export class RegisterPriceHeaderService {

  private static getRegisterPriceHeaderUrl = `http://localhost:8080/ibs/api/registerPriceHeader/`;

  constructor(private apiClient: ApiClientService) {
  }

  download(url:string){
    return this.apiClient.download(url);
  }
  getRegisterPriceHeader(criteria,fc) {
    return this.apiClient.get(RegisterPriceHeaderService.getRegisterPriceHeaderUrl + 'iso-search?criteria=' + criteria, fc);
  }
  updateRegisterPriceHeader(registerPriceHeader,id,fc) {
    return this.apiClient.put(RegisterPriceHeaderService.getRegisterPriceHeaderUrl + id, registerPriceHeader, fc);
  }
}
