import {Injectable} from '@angular/core';
import {ApiClientService} from "./api-client.service";
import {HttpClient} from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class InquiryService {

  private static getInquiryUrl = `http://localhost:8080/ibs/api/inquiry/`;
  private static getInquiryCountUrl = `http://localhost:8080/ibs/api/inquiry/inquiry-status-count`;

  constructor(private apiClient: ApiClientService,private http: HttpClient) {
  }

  getInquiry(criteria,fc) {
    return this.apiClient.get(InquiryService.getInquiryUrl + 'iso-search?criteria=' + criteria, fc);
  }

  getInquiryOther(criteria,fc) {
    return this.apiClient.get(InquiryService.getInquiryUrl + 'iso-search-oher?criteria=' + criteria, fc);
  }

  getInquiryCount(fc) {
    return this.apiClient.get(InquiryService.getInquiryCountUrl , fc);
  }

  updateInquiry(inquiry, id,fc) {
    return this.apiClient.put(InquiryService.getInquiryUrl + id , inquiry, fc);
  }
  updateInquiryStatus(id,fc) {
    return this.apiClient.put(InquiryService.getInquiryUrl + 'status/'+id , null , fc);
  }
  getCopyInquiry(id,fc) {
    return this.apiClient.put(InquiryService.getInquiryUrl + 'copy/'+id , null , fc);
  }
  download(url:string){
    return this.apiClient.download(url);
  }

}
