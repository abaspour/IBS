import {Injectable} from '@angular/core';
import {ApiClientService} from './api-client.service';

@Injectable({
  providedIn: 'root'
})
export class CustomService {

  private static getCustomUrl = `http://localhost:8080/ibs/api/custom/`;

  constructor(private apiClient: ApiClientService) {
  }


  getCustom(criteria,fc?) {
    return this.apiClient.get(CustomService.getCustomUrl + 'iso-search?criteria=' + criteria, fc);
  }
}
