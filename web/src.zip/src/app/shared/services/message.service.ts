import {Injectable} from '@angular/core';
import {ApiClientService} from "./api-client.service";

@Injectable({
  providedIn: 'root'
})

export class MessageService {

  private static getMessageUrl = `http://localhost:8080/ibs/api/message/`;

  constructor(private apiClient: ApiClientService) {
  }

  getMessage(criteria,fc) {
    return this.apiClient.get(MessageService.getMessageUrl + 'iso-search?criteria=' + criteria, fc);
  }

  createMessage(message,fc) {
    return this.apiClient.post(MessageService.getMessageUrl  , message, fc);
  }
  updateMessage(message, id,fc) {
    return this.apiClient.put(MessageService.getMessageUrl + id , message, fc);
  }
  updateMessageStatus(id,fc) {
    return this.apiClient.put(MessageService.getMessageUrl + 'status/'+id , null , fc);
  }
  download(url:string){
    return this.apiClient.download(url);
  }

}
