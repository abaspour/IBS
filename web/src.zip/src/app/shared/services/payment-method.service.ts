import {Injectable} from '@angular/core';
import {ApiClientService} from './api-client.service';

@Injectable({
  providedIn: 'root'
})
export class PaymentMethodService {

  private static getPaymentMethodUrl = `http://localhost:8080/ibs/api/paymentMethod/`;

  constructor(private apiClient: ApiClientService) {
  }


  getPaymentMethod(criteria,fc?) {
    return this.apiClient.get(PaymentMethodService.getPaymentMethodUrl + 'iso-search?criteria=' + criteria, fc);
  }
}
