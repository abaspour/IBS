import {Injectable} from '@angular/core';
import {ApiClientService} from './api-client.service';


@Injectable({
  providedIn: 'root'
})
export class ContractService {

  private static getContractUrl = `http://localhost:8080/ibs/api/contract/`;

  constructor(private apiClient: ApiClientService) {
  }

  getContract(criteria,fc?) {
    return this.apiClient.get(ContractService.getContractUrl + 'iso-search?criteria=' + criteria, fc);
  }
  updateContract(proform,id,fc) {
    return this.apiClient.put(ContractService.getContractUrl + id, proform, fc);
  }
  download(url:string){
    return this.apiClient.download(url);
  }

}
