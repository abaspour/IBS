import {Injectable} from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LocalstorageService {

  constructor() {
  }

  static getLang() {
    this.getToken();
    return localStorage.getItem('enFa');
  }

  static setWithExpiry() {
    const now = new Date()

    // `item` is an object which contains the original value
    // as well as the time when it's supposed to expire
    const item = {
      expiry: now.getTime() + 1800000
    }
    localStorage.setItem('key', JSON.stringify(item))
  }

  static getToken() {
    const itemStr = localStorage.getItem('key')
    if (!itemStr) {
      return null
    }
    const item = JSON.parse(itemStr)
    const now = new Date()
    if (now.getTime() > item.expiry) {
      this.clearAll();
    }
    this.setWithExpiry();
    return localStorage.getItem('token');
  }

  static setFaToken(value) {
    this.setWithExpiry();
    localStorage.setItem('enFa', 'fa');
    localStorage.setItem('token', value);
  }

  static setEnToken(value) {
    this.setWithExpiry();
    localStorage.setItem('enFa', 'en');
    localStorage.setItem('token', value);
  }

  static clearAll() {
    localStorage.clear();
  }


  static getBasicAuth() {
    return localStorage.getItem('basicauth');
  }

  static setBasicAuth(value) {
    localStorage.setItem('basicauth', value);
  }
}
