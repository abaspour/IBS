import {Injectable} from '@angular/core';
import {ApiClientService} from './api-client.service';

@Injectable({
  providedIn: 'root'
})

export class RegisterService {

  private static getRegisterUrl = `http://localhost:8080/ibs/api/anonymous/register/`;

  constructor(private apiClient: ApiClientService) {
  }


  getRegister(criteria,fc) {
    return this.apiClient.get(RegisterService.getRegisterUrl + 'iso-search?criteria=' + criteria, fc);

  }
  addRegister(register,fc) {
    return this.apiClient.post(RegisterService.getRegisterUrl, register, fc);
  }
}
