import {Injectable} from '@angular/core';
import {ApiClientService} from "./api-client.service";

@Injectable({
  providedIn: 'root'
})
export class InquiryPortageService {

  private static getInquiryPortageUrl = `http://localhost:8080/ibs/api/inquiryPortage/`;

  constructor(private apiClient: ApiClientService) {
  }

  download(url: string) {
    return this.apiClient.download(url);
  }

  getInquiryPortage(criteria, fc) {
    return this.apiClient.get(InquiryPortageService.getInquiryPortageUrl + 'iso-search?criteria=' + criteria, fc);
  }

  updateInquiryPortage(inquiryPortage, id, fc) {
    return this.apiClient.put(InquiryPortageService.getInquiryPortageUrl + id, inquiryPortage, fc);
  }
}
