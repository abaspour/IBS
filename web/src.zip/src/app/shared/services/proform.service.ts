import {Injectable} from '@angular/core';
import {ApiClientService} from "./api-client.service";

@Injectable({
  providedIn: 'root'
})
export class ProformService {

  private static getProformUrl = `http://localhost:8080/ibs/api/proform/`;

  constructor(private apiClient: ApiClientService) {
  }

  download(url:string){
    return this.apiClient.download(url);
  }
  getProform(criteria,fc) {
    return this.apiClient.get(ProformService.getProformUrl + 'iso-search?criteria=' + criteria, fc);
  }
  updateProform(proform,id,fc) {
    return this.apiClient.put(ProformService.getProformUrl + id, proform, fc);
  }
}
