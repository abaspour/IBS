import {Injectable} from '@angular/core';
import {ApiClientService} from './api-client.service';

@Injectable({
  providedIn: 'root'
})
export class CurrencyService {

  private static getCurrencyUrl = `http://localhost:8080/ibs/api/currency/`;

  constructor(private apiClient: ApiClientService) {
  }


  getCurrency(criteria,fc?) {
    return this.apiClient.get(CurrencyService.getCurrencyUrl + 'iso-search?criteria=' + criteria, fc);
  }
}
