import {Injectable} from '@angular/core';
import {ApiClientService} from './api-client.service';

@Injectable({
  providedIn: 'root'
})
export class PurchaseTypeService {

  private static getPurchaseTypeUrl = `http://localhost:8080/ibs/api/purchaseType/`;

  constructor(private apiClient: ApiClientService) {
  }


  getPurchaseType(criteria,fc?) {
    return this.apiClient.get(PurchaseTypeService.getPurchaseTypeUrl + 'iso-search?criteria=' + criteria, fc);
  }
}
