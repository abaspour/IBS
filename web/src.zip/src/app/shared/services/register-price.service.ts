import {Injectable} from '@angular/core';
import {ApiClientService} from "./api-client.service";

@Injectable({
  providedIn: 'root'
})
export class RegisterPriceService {

  private static getRegisterPriceUrl = `http://localhost:8080/ibs/api/registerPrice/`;

  constructor(private apiClient: ApiClientService) {
  }

  download(url:string){
    return this.apiClient.download(url);
  }
  getRegisterPrice(criteria,fc) {
    return this.apiClient.get(RegisterPriceService.getRegisterPriceUrl + 'iso-search?criteria=' + criteria, fc);
  }
  updateRegisterPrice(registerPrice,id,fc) {
    return this.apiClient.put(RegisterPriceService.getRegisterPriceUrl + id, registerPrice, fc);
  }
}
