import {Injectable} from '@angular/core';
import {ApiClientService} from './api-client.service';

@Injectable({
  providedIn: 'root'
})
export class UnitService {

  private static getUnitUrl = `http://localhost:8080/ibs/api/unit/`;

  constructor(private apiClient: ApiClientService) {
  }


  getUnit(criteria,fc?) {
    return this.apiClient.get(UnitService.getUnitUrl + 'iso-search?criteria=' + criteria, fc);
  }
}
