import {Injectable} from '@angular/core';
import {ApiClientService} from './api-client.service';

@Injectable({
  providedIn: 'root'
})
export class CountryService {

  private static getCountryUrl = `http://localhost:8080/ibs/api/anonymous/country/`;

  constructor(private apiClient: ApiClientService) {
  }


  getCountry(fc?) {
    return this.apiClient.getAno(CountryService.getCountryUrl + 'iso-search', fc);
  }

}
