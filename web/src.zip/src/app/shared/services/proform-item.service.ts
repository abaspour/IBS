import {Injectable} from '@angular/core';
import {ApiClientService} from "./api-client.service";

@Injectable({
  providedIn: 'root'
})
export class ProformItemService {

  private static getProformItemUrl = `http://localhost:8080/ibs/api/proformitem/`;

  constructor(private apiClient: ApiClientService) {
  }

  download(url:string){
    return this.apiClient.download(url);
  }
  getProformItem(criteria,fc) {
    return this.apiClient.get(ProformItemService.getProformItemUrl + 'iso-search?criteria=' + criteria, fc);
  }
  updateProformItem(proformItem,id,fc) {
    return this.apiClient.put(ProformItemService.getProformItemUrl + id, proformItem, fc);
  }
}
