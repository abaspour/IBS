import {Injectable} from '@angular/core';
import {ApiClientService} from './api-client.service';

@Injectable({
  providedIn: 'root'
})
export class TransmitInstrumentService {

  private static getTransmitInstrumentUrl = `http://localhost:8080/ibs/api/transmitInstrument/`;

  constructor(private apiClient: ApiClientService) {
  }


  getTransmitInstrument(criteria,fc?) {
    return this.apiClient.get(TransmitInstrumentService.getTransmitInstrumentUrl + 'iso-search?criteria=' + criteria, fc);
  }
}
