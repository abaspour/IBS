
export interface PurchaseType {
  id: string,
  nameFa: string,
  nameEn: string,
  isActive: string,
}
