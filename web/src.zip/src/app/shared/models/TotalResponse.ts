import {GridResponse} from './GrideResponse';

export interface TotalResponse<> {
  response: GridResponse;
}
