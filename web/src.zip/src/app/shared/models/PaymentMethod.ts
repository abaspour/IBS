export interface PaymentMethod {
  id: string,
  nameFa: string,
  nameEn: string,
  isActive: string,
}
