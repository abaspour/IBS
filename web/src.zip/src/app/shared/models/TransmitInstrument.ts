export interface TransmitInstrument {
  id: string,
  nameFa: string,
  nameEn: string,
  isActive: string,
}
