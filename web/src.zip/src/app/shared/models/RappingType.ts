export interface RappingType {
  id: string,
  nameFa: string,
  nameEn: string,
  isActive: string,
}
