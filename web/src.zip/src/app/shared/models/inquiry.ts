import {DeliveryLocation} from "./delivery-location";

export interface Inquiry {
  id: string,
  inquiryNumber: string,
  inquiryName: string,
  inquiryDate: string,
  sendDate: string,
  endReplyDate: string,
  inquiryType: string,

  enCancelDate: string,
  enInquiryDate: string,
  enSendDate: string,
  enEndReplyDate: string,
  validTime: string,

  inquiryDesc: string,
  testDesc: string,
  briefingPlace: string,
  briefingDate: string,
  technicalDesc: string,
  verify: string,
  portage: string
  instalCost: string
  otherCost: string
  checkOffer: string
  spareProductTime: string,
  spareProductTimeRequire: string,
  briefing: string,
  replyDate: string,
  attachmentFileName: string,
  supDesc: string,
  cancelDate: string,
  verifyStatus: string,
  changeStatus: string,

  deliveryLocation : DeliveryLocation
}
