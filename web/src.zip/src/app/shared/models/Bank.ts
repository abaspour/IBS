export interface Bank {
  id: string,
  nameFa: string,
  nameEn: string,
  isActive: string,
}
