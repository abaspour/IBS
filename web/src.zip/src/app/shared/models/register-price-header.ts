export interface RegisterPriceHeader {
  id: number;
  inquiryNumber: string
  supplierId: string
  portageCost: string
  subSpareProductCost: string
  otherCost: string
  discount: string
  sumPrice: string
  taxCost: string
  checkInfo: string
  subInstallCost: string
  portage: string
  installCostRequire: string
  otherCostRequire: string
  spareProductFileDateCreated: string
  spareProductFileSize: string
  spareProductFileName: string
  taxCostValue: number;
  supplierResponseTime: string
  supplierResponseDate: string
  spareProductFileNewName: string
  replyDate: string
  sumPrincipal: number;
  changeStatus: string
  packingCost: string
// from inquiry
  spareProductTime: string;
  inquiryType: string,

}
