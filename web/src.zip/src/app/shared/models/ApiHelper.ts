export interface FormContainer {
  isWorking: boolean;
  handleError?: any;
}
