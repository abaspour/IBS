export interface Currency {
  id: string,
  nameFa: string,
  nameEn: string,
  isActive: string,
}
