import {Currency} from "./Currency";
import {PaymentMethod} from "./PaymentMethod";
import {PurchaseType} from "./PurchaseType";
import {TransmitInstrument} from "./TransmitInstrument";
import {RappingType} from "./RappingType";
import {Country} from "../../country";
import {Custom} from "./Custom";
import {Freight} from "./Freight";
import {Bank} from "./Bank";

export interface Proform {
    id: number,
    supplierId: number,
    requestId: number,
    userId: number,
    inquiryNumber: string,
    proformdscen: string,
    proformnumber: string,
    prformdate: string,
    proformexpiredate: string,
    totalsumitemscost: number,
    discountproform: number,
    rappingcost: number,
    usancecost: number,
    othercost: number,
    pureweight: string,
    impureweight: string,
    mass: string,
    deliverttime: string,
    constructorname: string,
    assigndate: string,
    fca: string,
    totalprice: string,
    deliveryCount: string,
    convertRateRial: string,
    convertRateDollar: string,
    convertRateEuro: string,
   freightId: number,
   currencyId: number,
   fpaymentMethodId: number,
   purchaseTypeId: number,
   transmitInstrumentId: number,
   rappingTypeId: number,
   countryId: number,
   countryLoadingId: number,
   beneficiaryCountryId: number,
   beneficiaryDeliveryCountryId: number,
   bankId: number,
   customId: number,

  paymentMethodId: number,

    currency: Currency,
    paymentMethod: PaymentMethod,
    purchaseType: PurchaseType,
    transmitInstrument: TransmitInstrument,
    rappingType: RappingType,
    country: Country,
    countryLoading: Country,
    beneficiaryCountry: Country,
    beneficiaryDeliveryCountry: Country,
    freight: Freight,
    bank: Bank,
    custom: Custom,
    createdDate,
    createdBy: string,
    lastModifiedDate,
    lastModifiedBy: string,
    version: number,
    replyDate: string


}
