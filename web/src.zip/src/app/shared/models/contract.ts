
export interface Contract {
  id: string,
  supplierId: string,
  requestId: string,
  purchaseOrder: string,
  code: string,
  dsc: string,
  status: string,
  fileNewName: string,
  fileOldName: string,
}
