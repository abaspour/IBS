export interface Custom {
  id: string,
  nameFa: string,
  nameEn: string,
  isActive: string,
}
