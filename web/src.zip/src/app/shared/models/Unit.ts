export interface Unit {
  id: string,
  nameFa: string,
  nameEn: string,
  isActive: string,
}
