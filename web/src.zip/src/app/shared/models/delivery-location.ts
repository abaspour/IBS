export interface DeliveryLocation {
  id: number;
  deliveryNameFa: string;
}
