import {Country} from "../../country";
import {Proform} from "./Proform";
import {Unit} from "./Unit";
import {RequestItem} from "./RequestItem";

export interface ProformItem {
    id: number,
    price: string,
    amount: number,
    attachmentFileName: string,
    attachmentDateCreated: string,
    attachmentNewName: string,
    attachmentFileSize: number,
   itemDescl: string,
   requestItemSpec: string,
   totalPrice: string,
   constructorName: string,
   verifyPrice: string,
   itemDescription: string,
   ignorePricing: string,
   technicalDesc: string,
   warrantyDesc: string,
   packingDesc: string,

  requestItemId: number,
  unitId: number,
  proformId: number,
  countryByConstructureId: number,


    requestItem: RequestItem,
    unit: Unit,
    proform: Proform,
    countryByConstructure: Country,

  // from attachments and maps
  listAttachIds:[string],
  listAttachFileName:[string],
  listAttachDesc:[string],

  currencyId: number
}
