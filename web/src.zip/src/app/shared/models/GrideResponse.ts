export interface GridResponse<> {
  data: any;
  status: number;
  startRow: number;
  endRow: number;
  totalRows: number;
  invalidateCache: boolean;
}
