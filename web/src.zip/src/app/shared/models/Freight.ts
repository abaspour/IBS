export interface Freight {
  id: string,
  nameFa: string,
  nameEn: string,
  isActive: string,
}
