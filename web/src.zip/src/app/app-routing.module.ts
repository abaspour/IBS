import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {Notfound404Component} from './notfound404/notfound404.component';
import {MainPageComponent} from './main-page/main-page.component';
import {AuditFormComponent} from './audit-form/audit-form.component';
import {HelpAuditComponent} from './help-audit/help-audit.component';
import {WelcomeComponent} from "./welcome/welcome.component";
import {InquiryNewComponent} from "./inquiry-new/inquiry-new.component";
import {InquiryCommonComponent} from "./inquiry-common/inquiry-common.component";
import {ItemListComponent} from "./item-list/item-list.component";
import {ItemComponent} from "./item/item.component";
import {OtherComponent} from "./other/other.component";
import {SendComponent} from "./send/send.component";
import {OtherGuard} from "./other/other.guard";
import {ItemGuard} from "./item/item.guard";
import {SendGuard} from "./send/send.guard";
import {LoginComponent} from "./login/login.component";
import {LoginGuard} from "./shared/services/login.guard";
import {InquiryRepliedComponent} from "./inquiry-replied/inquiry-replied.component";
import {InquiryCanceledComponent} from "./inquiry-canceled/inquiry-canceled.component";
import {InquiryRevokedComponent} from "./inquiry-revoked/inquiry-revoked.component";
import {CancelComponent} from "./cancel/cancel.component";
import {EnLoginGuard} from "./shared/services/en-login.guard";
import {EnInquiryNewComponent} from "./en-inquiry-new/en-inquiry-new.component";
import {EnLoginComponent} from "./en-login/en-login.component";
import {EnInquiryRepliedComponent} from "./en-inquiry-replied/en-inquiry-replied.component";
import {EnInquiryCanceledComponent} from "./en-inquiry-canceled/en-inquiry-canceled.component";
import {EnInquiryRevokedComponent} from "./en-inquiry-revoked/en-inquiry-revoked.component";
import {EnInquiryCommonComponent} from "./en-inquiry-common/en-inquiry-common.component";
import {EnItemListComponent} from "./en-item-list/en-item-list.component";
import {EnOtherGuard} from "./en-other/en-other.guard";
import {EnOtherComponent} from "./en-other/en-other.component";
import {EnCancelComponent} from "./en-cancel/en-cancel.component";
import {EnItemComponent} from "./en-item/en-item.component";
import {EnItemGuard} from "./en-item/en-item.guard";
import {EnSendComponent} from "./en-send/en-send.component";
import {EnSendGuard} from "./en-send/en-send.guard";
import {ContractComponent} from "./contract/contract.component";
import {EnContractComponent} from "./en-contract/en-contract.component";
import {MessageComponent} from "./message/message.component";
import {MessageGuard} from "./message/message.guard";
import {InquiryMessageComponent} from "./inquiry-message/inquiry-message.component";
import {PoSendGuard} from "./po-send/po-send.guard";
import {PoSendComponent} from "./po-send/po-send.component";

const routes: Routes = [
  {path: '', component: MainPageComponent},
  {path: 'audit-form/:regNo/:regCountry', component: AuditFormComponent},
  {path: 'help-audit', component: HelpAuditComponent},
  {path: 'welcome', component: WelcomeComponent},
  {path: 'login', component: LoginComponent},
  {path: 'enLogin', component: EnLoginComponent},
  {path: 'inquiry', canActivate:[LoginGuard],component: InquiryNewComponent},
  {path: 'enInquiry', canActivate:[EnLoginGuard],component: EnInquiryNewComponent},
  {path: 'replied', canActivate:[LoginGuard],component: InquiryRepliedComponent},
  {path: 'contract', canActivate:[LoginGuard],component: ContractComponent},
  {path: 'enContract', canActivate: [EnLoginGuard], component: EnContractComponent},
  {path: 'enReplied', canActivate:[EnLoginGuard],component: EnInquiryRepliedComponent},
  {path: 'canceled', canActivate:[LoginGuard],component: InquiryCanceledComponent},
  {path: 'messages', canActivate:[LoginGuard],component: InquiryMessageComponent},
  {path: 'enCanceled', canActivate:[EnLoginGuard],component: EnInquiryCanceledComponent},
  {path: 'revoked', canActivate:[LoginGuard],component: InquiryRevokedComponent},
  {path: 'enRevoked', canActivate:[EnLoginGuard],component: EnInquiryRevokedComponent},
  {path: 'inquiry-common/:inquiryNumber', canActivate:[LoginGuard], component: InquiryCommonComponent},
  {path: 'enInquiry-common/:inquiryNumber', canActivate:[EnLoginGuard], component: EnInquiryCommonComponent},
  {path: 'item-list/:inquiryNumber', canActivate:[LoginGuard], component: ItemListComponent},
  {path: 'enItem-list/:inquiryNumber', canActivate: [EnLoginGuard], component: EnItemListComponent},
  {path: 'other/:inquiryNumber', canActivate:[LoginGuard], canDeactivate :[OtherGuard],  component: OtherComponent},
  {path: 'enOther/:inquiryNumber', canActivate: [EnLoginGuard], canDeactivate :[EnOtherGuard],  component: EnOtherComponent},
  {path: 'send/:inquiryNumber', canActivate:[LoginGuard], canDeactivate :[SendGuard], component: SendComponent},
  {path: 'enSend/:inquiryNumber', canActivate: [EnLoginGuard], canDeactivate :[EnSendGuard], component: EnSendComponent},
  {path: 'poSend/:inquiryNumber', canActivate: [LoginGuard], canDeactivate: [PoSendGuard], component: PoSendComponent},
  {path: 'item/:id', canActivate:[LoginGuard], canDeactivate :[ItemGuard], component: ItemComponent},
  {path: 'enItem/:id', canActivate: [EnLoginGuard], canDeactivate :[EnItemGuard], component: EnItemComponent},
  {path: 'message/:inquiryNumber', canActivate:[LoginGuard],  canDeactivate :[MessageGuard],component: MessageComponent},
  {path: 'cancel/:inquiryNumber', canActivate:[LoginGuard],  component: CancelComponent},
  {path: 'enCancel/:inquiryNumber', canActivate: [EnLoginGuard],  component: EnCancelComponent},
  {path: 'notFound', component: Notfound404Component, data: [{message: ' صفحه یافت نشد Page not Found'}]},
  {path: '**', redirectTo: 'notFound'}
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
