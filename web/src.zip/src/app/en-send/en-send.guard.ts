import {Injectable} from '@angular/core';
import {CanDeactivate} from '@angular/router';
import {Observable} from 'rxjs';
import {EnSendComponent} from "./en-send.component";


@Injectable({
  providedIn: 'root'
})
export class EnSendGuard implements CanDeactivate<EnSendComponent> {
  canDeactivate(component: EnSendComponent): Observable<boolean> | Promise<boolean> | boolean {
    if (component.form.dirty) {
      const countryName = component.form.get('inquiryNumber').value || ' ?  ';
      return confirm(`Loose change(s) on screen for Inquiry ${countryName}?`);
    }
    return true;
  }
}

