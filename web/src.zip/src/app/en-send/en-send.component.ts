import {Component, OnInit} from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {ActivatedRoute, Data, Router} from "@angular/router";
import {ToastrService} from "ngx-toastr";
import {TotalResponse} from "../shared/models/TotalResponse";
import {Subscription} from "rxjs";
import {Inquiry} from "../shared/models/inquiry";
import {InquiryService} from "../shared/services/inquiry.service";
import {Proform} from "../shared/models/Proform";
import {ProformService} from "../shared/services/proform.service";
import {formatDate} from "@angular/common";

export const num2prcision = "^\\d*\\.?\\d{0,2}$";
export const num = "^\\d*$";
export const EnglishAlphabetRegex = '^[a-zA-Z]\\S*$';
export const telRegex = '^[+(]{1}\\d{1,4}[\\s)]{0,1}\\d{1,3}\\s{0,1}\\d{3,15}$';

@Component({
  selector: 'app-en-send',
  templateUrl: './en-send.component.html',
  styleUrls: ['./en-send.component.scss']
})
export class EnSendComponent implements OnInit {

  inquiries: [Inquiry];
  proforms: [Proform];
  fileData: File = null;
  previewUrl: any = null;
  form: FormGroup = null;
  startRow = 1;
  totalRows = 0;
  page = 5;
  endRow = 5;
  errorMessage = '';
  inquiryNumber: string;
  inquiryName: string;
  inquiryDate: string;
  endReplyDate: string;
  filter = false;
  formSubmitAttempt = false;
  commitInq = false;
  commitPro = false;

  criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"supplierId", "operator":"notNull" } ] } `;

  constructor(private router: Router,
              private toastr: ToastrService,
              private activeRouter: ActivatedRoute,
              private proformService: ProformService,
              private inquiryService: InquiryService) {
  }

  ngOnInit() {
    this.form = new FormGroup({
      inquiryNumber: new FormControl(null),
      verify_: new FormControl('', Validators.required),
      file__: new FormControl('', Validators.required),
      proformnumber: new FormControl('', Validators.required),
      prformdate: new FormControl('', Validators.required),
      proformexpiredate: new FormControl('', Validators.required),
      proformdscen: new FormControl('', Validators.required)
    });
    this.sub = this.activeRouter.params.subscribe((data: Data) => {
      this.inquiryNumber = data.inquiryNumber;
      if (this.inquiryNumber) {
        this.criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"inquiryNumber", "operator":"equals", "value": "${this.inquiryNumber}"  } ] } `;
        this.subscribe(this.criteria + `&_startRow=${this.startRow - 1}&_endRow=${this.endRow}&_sortBy=inquiryNumber`);
      }
    });
  }

  private sub: Subscription;

  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }

  subscribe(criteria) {
    this.inquiryService.getInquiry(criteria, this).subscribe({
      next: (data: TotalResponse) => {
        this.inquiries = data.response.data;
        this.inquiries.forEach(_ => {
          this.form.patchValue(
            {
              inquiryNumber: _.inquiryNumber,
              verify_: _.verify,
            });
        });
        this.endRow = data.response.endRow;
        this.startRow = data.response.startRow + 1;
        this.totalRows = data.response.totalRows;
      }
    });
    this.proformService.getProform(criteria, this).subscribe({
      next: (data: TotalResponse) => {
        this.proforms = data.response.data;
        this.proforms.forEach(_ => {
          let aa = _.prformdate ? new Date(_.prformdate + ' 12:00') : new Date();
          let bb = _.proformexpiredate ? new Date(_.proformexpiredate + ' 12:00') : new Date();
          this.form.patchValue(
            {
              proformnumber: _.proformnumber,
              prformdate: aa.toISOString().substring(0, 10),
              proformexpiredate: bb.toISOString().substring(0, 10),
              proformdscen: _.proformdscen,
            });
        });
        this.endRow = data.response.endRow;
        this.startRow = data.response.startRow + 1;
        this.totalRows = data.response.totalRows;
      }
    })
    // error : err => this.errorMessage = err
  }

  onClickBack(inq) {
    this.router.navigate([`enOther/${inq}`]);
  }

  isFieldValid(field: string) {
    if (this.form.get(field).valid) {
      return null;
    }
    return (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSubmitAttempt);
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  fileProgress(fileInput: any) {
    this.fileData = <File>fileInput.target.files[0];
    this.preview();
  }

  preview() {
    // Show preview
    const mimeType = this.fileData.type;
    if (mimeType.match(/image\/*/) == null) {
      return;
    }

    let reader = new FileReader();
    reader.readAsDataURL(this.fileData);
    reader.onload = (_event) => {
      this.previewUrl = reader.result;
    };
  }

  onClickNxt() {
    if (!this.form.get('verify_').value) {
      this.toastr.error('Please click "We Have Read All the Documents And Information"',
        'error', {timeOut: 5000});
      this.formSubmitAttempt = false;
      return;
    }
    this.formSubmitAttempt = true;
    if (this.form.valid && this.form.dirty) {
      let _ = this.form.getRawValue();
//
      this.inquiries[0].inquiryNumber = _.inquiryNumber;
      this.inquiries[0].verify = _.verify_;
      this.inquiries[0].verifyStatus = "r";
      this.inquiries[0].changeStatus = "2";
//
      const formData = new FormData();
      formData.append('data', JSON.stringify(this.inquiries[0]));
      formData.append('file', this.fileData);

      this.inquiryService.updateInquiry(formData,
        this.inquiries[0].id, this).subscribe(data => {
          this.commitInq = true;
          if (this.commitPro) {
            this.toastr.success(' Submited.', 'success', {timeOut: 10000});
            setTimeout(() => {
              this.form.reset();
              this.router.navigate([`enInquiry`]);
            }, 200);
            this.formSubmitAttempt = false;
          }
        },
        error => {
          this.toastr.error(' Error .' + JSON.stringify(error.error), 'Error', {timeOut: 10000});
          setTimeout(() => {
            // this.router.navigate(['/']);
          }, 20000);
        }
      );
      let d2 = _.proformexpiredate;
      d2 = d2.setTime(12);
      let d1 = _.prformdate
      d1 = d1.setTime(12);
      this.proforms[0].proformnumber = _.proformnumber;
      this.proforms[0].prformdate = formatDate(d1, 'yyyy/MM/dd', 'en_US');
      this.proforms[0].proformexpiredate = formatDate(d2, 'yyyy/MM/dd', 'en_US');
      this.proforms[0].proformdscen = _.proformdscen;
//
      const formData1 = new FormData();
      formData1.append('data', JSON.stringify(this.proforms[0]));

      this.proformService.updateProform(formData1,
        this.proforms[0].id, this).subscribe(data => {
          this.commitPro=true;
          if (this.commitInq) {
            this.toastr.success('Submited', 'success', {timeOut: 10000});
            setTimeout(() => {
              this.form.reset();
              this.router.navigate([`enInquiry`]);
            }, 200);
            this.formSubmitAttempt = false;
          }
        },
        error => {
          this.toastr.error(' Error .' + JSON.stringify(error.error), 'Error', {timeOut: 10000});
          setTimeout(() => {
            // this.router.navigate(['/']);
          }, 20000);
        }
      );

    } else if (this.form.valid) {
      this.router.navigate([`enInquiry`]);
    } else {
      this.toastr.error('Please fix error(s).', 'error', {timeOut: 10000});
    }

  }
}
