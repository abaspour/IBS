export interface Country {
  id: number,
  countryNameEn: string,
  countryCode: string,
  countryCallingCode: string,
  countryNameLocal: string
}
