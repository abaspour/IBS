import {Component, OnInit} from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import {ToastrService} from "ngx-toastr";
import {InquiryService} from "../shared/services/inquiry.service";
import {TotalResponse} from "../shared/models/TotalResponse";
import {Inquiry} from "../shared/models/inquiry";

@Component({
  selector: 'app-en-inquiry-new',
  templateUrl: './en-inquiry-new.component.html',
  styleUrls: ['./en-inquiry-new.component.scss']
})
export class EnInquiryNewComponent implements OnInit {

  inquiries : [Inquiry];
  isWorking= false;
  form: FormGroup = null;
  startRow = 1;
  totalRows = 0;
  page =5;
  endRow = 5;
  errorMessage = '';
  inquiryNumber: string;
  inquiryName: string;
  inquiryDate: string;
  endReplyDate: string;
  filter = false;
  formSubmitAttempt = false;
  criteria = `{ "operator":"and", "criteria" : [  { "fieldName":"supplierId", "operator":"notNull"  } ] } `;
  constructor(private router: Router,
              private toastr: ToastrService,
              private inquiryService: InquiryService) {
  }

  ngOnInit() {
    this.form = new FormGroup({
      inquiryNumber: new FormControl(null, Validators.required),
      inquiryName: new FormControl('', Validators.required),
      inquiryDate: new FormControl('', Validators.required),
      endReplyDate: new FormControl('', Validators.required)
    });

    this.subscribe( this.criteria + `&_startRow=${this.startRow-1}&_endRow=${this.endRow}&_sortBy=-endReplyDate&_sortBy=-inquiryNumber` );
  }
  subscribe(criteria){
    this.inquiryService.getInquiry(criteria,this).subscribe({
      next: (data: TotalResponse) => {
        this.inquiries = data.response.data;
        this.endRow=data.response.endRow;
        this.startRow=data.response.startRow+1;
        this.totalRows=data.response.totalRows;
      }
      // error : err => this.errorMessage = err
    });

  }
  onClickPrv(){
    if (this.startRow!=1) {
      this.endRow=this.startRow -1;
      this.startRow=(this.startRow-this.page > 0) ? this.startRow-this.page : 1 ;
      this.subscribe(this.criteria+ `&_startRow=${this.startRow-1}&_endRow=${this.endRow}&_sortBy=-endReplyDate&_sortBy=-inquiryNumber`);
    }
  }
  onClickNxt(){
    if (this.endRow!=this.totalRows) {
      this.startRow=this.endRow + 1;
      this.endRow=(this.endRow + this.page <= this.totalRows) ? this.endRow + this.page : this.totalRows;
      this.subscribe(this.criteria+ `&_startRow=${this.startRow-1}&_endRow=${this.endRow}&_sortBy=-endReplyDate&_sortBy=-inquiryNumber`);
    }
  }
  onClickSerchClr(){
    this.inquiryNumber='';
    this.inquiryName='';
    this.inquiryDate='';
    this.endReplyDate='';
    this.onClickSerch();
  }
  onClickSerch(){
    this. criteria = `{ "operator":"and", "criteria" : [   { "fieldName":"supplierId", "operator":"notNull"  } `;
    this.filter = false;
    if (this.inquiryNumber) {
      this.filter = true;
      this.criteria += `,{ "fieldName":"inquiryNumber", "operator":"iContains", "value": "${this.inquiryNumber}"  } `;
    }
    if (this.inquiryName){
      this.filter = true;
      this.criteria += `,{ "fieldName":"inquiryName", "operator":"iContains", "value": "${this.inquiryName}"  } `;
    }
    if (this.inquiryDate){
      this.filter = true;
      this.criteria += `,{ "fieldName":"inquiryDate", "operator":"iContains", "value": "${this.inquiryDate}"  } `;
    }
    if (this.endReplyDate){
      this.filter = true;
      this.criteria += `,{ "fieldName":"endReplyDate", "operator":"iContains", "value": "${this.endReplyDate}"  } `;
    }
    this.criteria += `] } `;
    this.startRow = 1;
    this.endRow = this.page;
    this.subscribe(this.criteria+ `&_startRow=${this.startRow-1}&_endRow=${this.endRow}&_sortBy=-endReplyDate&_sortBy=-inquiryNumber`);

  }
  onClickR() {
    this.formSubmitAttempt = true;
    if (this.form.get('inquiryNo').value && this.form.get('inquiryCountry').value && this.form.get('contactPersonEmail').value) {
      // this.form.patchValue({countryCallingCode: '93' });
      const criteria= ` ${this.form.get('inquiryNo').value} , ${this.form.get('inquiryCountry').value} , ${this.form.get('contactPersonEmail').value} `;
      // console.log('criteria=', criteria);
      this.inquiryService.getInquiry(criteria,this).subscribe((x: TotalResponse) => {
        if (x.response.totalRows < 0) {
          this.toastr.warning(" error in sending eMail .",'error',{timeOut: 10000});
        } else
        if (x.response.totalRows > 0) {
          this.toastr.info(
            `  inquiryNo:${this.form.get('inquiryNo').value} in Country: already inquiryd in NICICO system. We will contact you by Email.`,
            'info', {timeOut: 10000});
        } else {
          this.toastr.info( " Email sent. please use ID from email in next section and press Continue.");
        }
      });
    }
  }

  onClickB() {
    this.router.navigate(['/']);
  }

  isFieldValid(field: string) {
    return (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSubmitAttempt);
  }

  displayFieldCss(inquiry:Inquiry) {
    return {
      'new': inquiry.verifyStatus==='n'
    };
  }
}
