import {Component, OnInit} from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {Inquiry} from "../shared/models/inquiry";
import {Router} from "@angular/router";
import {ToastrService} from "ngx-toastr";
import {InquiryService} from "../shared/services/inquiry.service";
import {TotalResponse} from "../shared/models/TotalResponse";

@Component({
  selector: 'app-inquiry-canceled',
  templateUrl: './inquiry-canceled.component.html',
  styleUrls: ['./inquiry-canceled.component.scss']
})
export class InquiryCanceledComponent implements OnInit {


  // @ViewChild('mySelect' , {static: false}) mySelect;
  inquiries : [Inquiry];
  isWorking= false;
  form: FormGroup = null;
  pageTitle = 'استعلامهای انصراف داده شده';
  startRow = 1;
  totalRows = 0;
  page =5;
  endRow = 5;
  errorMessage = '';
  inquiryNumber: string;
  inquiryDesc: string;
  supDesc: string;
  cancelDate: string;
  filter = false;
  formSubmitAttempt = false;
  criteria =
    `{ "operator":"or", "criteria" : 
             [  { "fieldName" : "verifyStatus", "operator": "equals", "value" : "c" } ,
                { "operator":"and", "criteria" : [
                                 { "fieldName":"endReplyDate", "operator":"lessThan", "value": "+dateTimeStrRs.getDate()+"  } , 
												 			   { "operator" : "or", "criteria\": [
												 			                                        { "fieldName" : "verifyStatus", "operator": "equals", "value" : "n" }, 
																	                                    { "fieldName" : "verifyStatus", "operator": "equals", "value" : "v" } 
						                                   									   ]  }
																]	}
						]
			}	 `;
  baseCriteria: string;
  constructor(private router: Router,
              private toastr: ToastrService,
              private inquiryService: InquiryService) {
  }

  ngOnInit() {
    this.form = new FormGroup({
      inquiryNumber: new FormControl(null, Validators.required),
      inquiryName: new FormControl('', Validators.required),
      inquiryDate: new FormControl('', Validators.required),
      cancelDate: new FormControl('', Validators.required)
    });
    this.baseCriteria = this.criteria;
    this.subscribe(this.criteria + `&_startRow=${this.startRow - 1}&_endRow=${this.endRow}&_sortBy=-inquiryNumber`);
  }
  subscribe(criteria){
    this.inquiryService.getInquiryOther(criteria,this).subscribe({
      next: (data: TotalResponse) => {
        this.inquiries = data.response.data;
        this.endRow=data.response.endRow;
        this.startRow=data.response.startRow+1;
        this.totalRows=data.response.totalRows;
      }
      // error : err => this.errorMessage = err
    });

  }
  onClickPrv(){
    if (this.startRow!=1) {
      this.endRow=this.startRow -1;
      this.startRow=(this.startRow-this.page > 0) ? this.startRow-this.page : 1 ;
      this.subscribe(this.criteria + `&_startRow=${this.startRow - 1}&_endRow=${this.endRow}&_sortBy=-inquiryNumber`);
    }
  }
  onClickNxt(){
    if (this.endRow!=this.totalRows) {
      this.startRow=this.endRow + 1;
      this.endRow=(this.endRow + this.page <= this.totalRows) ? this.endRow + this.page : this.totalRows;
      this.subscribe(this.criteria + `&_startRow=${this.startRow - 1}&_endRow=${this.endRow}&_sortBy=-inquiryNumber`);
    }
  }
  onClickSerchClr(){
    this.inquiryNumber='';
    this.inquiryDesc='';
    this.supDesc='';
    this.cancelDate='';
    this.onClickSerch();
  }
  // inquiryDesc|| supDesc|| cancelDate
  onClickSerch(){
    this.criteria = `{ "operator":"and", "criteria" : [  ${this.baseCriteria} `;
    this.filter = false;
    if (this.inquiryNumber) {
      this.filter = true;
      this.criteria += `,{ "fieldName":"inquiryNumber", "operator":"iContains", "value": "${this.inquiryNumber}"  } `;
    }
    if (this.inquiryDesc){
      this.filter = true;
      this.criteria += `,{ "fieldName":"inquiryDesc", "operator":"iContains", "value": "${this.inquiryDesc}"  } `;
    }
    if (this.supDesc){
      this.filter = true;
      this.criteria += `,{ "fieldName":"supDesc", "operator":"iContains", "value": "${this.supDesc}"  } `;
    }
    if (this.cancelDate){
      this.filter = true;
      this.criteria += `,{ "fieldName":"cancelDate", "operator":"iContains", "value": "${this.cancelDate}"  } `;
    }
    this.criteria += `] } `;
    this.startRow = 1;
    this.endRow = this.page;
    this.subscribe(this.criteria + ` & _startRow =${this.startRow - 1}&_endRow =${this.endRow}&_sortBy = -inquiryNumber`);

  }

  onClickB() {
    this.router.navigate(['/']);
  }

  isFieldValid(field: string) {
    return (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSubmitAttempt);
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }
  download(urll): void {
    this.inquiryService.download(urll).subscribe(blob => {
      const a = document.createElement('a')
      const objectUrl = URL.createObjectURL(blob)
      a.href = objectUrl
      a.download = 'file';
      a.click();
      URL.revokeObjectURL(objectUrl);
    });
  }

}
